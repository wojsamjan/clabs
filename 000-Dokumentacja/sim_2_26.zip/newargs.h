/*	This file is part of the software similarity tester SIM.
	Written by Dick Grune, Vrije Universiteit, Amsterdam.
	$Id: newargs.h,v 2.1 2008/09/23 09:07:11 dick Exp $
*/

extern void get_new_args(int *argcp, const char **argvp[]);
