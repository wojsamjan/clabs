/*	This file is part of the software similarity tester SIM.
	Written by Dick Grune, Vrije Universiteit, Amsterdam.
	$Id: percentages.h,v 1.3 2008/03/31 10:35:17 dick Exp $
*/

extern void add_to_percentages(struct run *r);
extern void show_percentages(void);
