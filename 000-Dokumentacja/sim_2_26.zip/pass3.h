/*	This file is part of the software similarity tester SIM.
	Written by Dick Grune, Vrije Universiteit, Amsterdam.
	$Id: pass3.h,v 1.2 1998/01/21 14:28:01 dick Exp $
*/

/*	Print the contents of runs */
extern void Pass3(void);
