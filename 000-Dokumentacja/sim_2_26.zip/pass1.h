/*	This file is part of the software similarity tester SIM.
	Written by Dick Grune, Vrije Universiteit, Amsterdam.
	$Id: pass1.h,v 1.4 2008/09/23 09:07:12 dick Exp $
*/

/*	Reads the input files; stores the tokens in TOKEN TokenArray[]
	and the input file descriptions in struct text text[].
*/
extern void Pass1(int argc, const char *argv[]);
