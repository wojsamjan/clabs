/* Copyright (c) 1991 by the Vrije Universiteit, Amsterdam, the Netherlands.
 * For full copyright and restrictions on use see the file COPYING in the top
 * level of the LLgen tree.
 */

/* $Id: cclass.h,v 2.8 1997/02/21 11:27:43 ceriel Exp $ */

extern char c_class[];

#define ISLET 1
#define ISDIG 2
#define ISSPA 3
#define ISKEY 4
#define ISTOK 5
#define ISCOM 6
#define ISLIT 7
#define ISACT 8
