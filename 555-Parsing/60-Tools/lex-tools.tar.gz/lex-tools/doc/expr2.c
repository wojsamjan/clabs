/*************************************************
This is a simple double-precision calculator.  It
evaluates expressions based on this grammar:

        E : E + T
          | E - T
          | T

        T : T * P
          | T / P
          | P

        P : F ^ P
          | F

        F : number
          | ( E )

Eliminating left recursion leads to this version
which we implement here in a recursive descent
parser:

        E : T E'

        E' : + T
           | - T
           | <empty>

        T : P T'

        T' : * P
           | / P
           | <empty>

        P : F ^ P
          | F

        F : number
          | ( E )

Support functions are nextnb() to get the next
non-blank character, and peeknb() to peek at the
next non-blank character.  The expression to be
parsed is stored in a global buffer, with pc
pointing to the next available character.  Parsing
of a number is handled by the standard library
routine, strtod().

[11-Apr-1991]
*************************************************/

#if    __STDC__
#define ARGS(plist)             plist
#else  /* NOT __STDC__ */
#define ARGS(parenthesized_list) ()
#endif

#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <math.h>

#ifndef EXIT_SUCCESS
#define EXIT_SUCCESS 0
#endif

void    error ARGS((void));
void    expect ARGS((int c));
double  expr ARGS((void));
double  factor ARGS((void));
void    initialize ARGS((void));
int     main ARGS((int argc, char* argv[]));
int     nextnb ARGS((void));
int     peeknb ARGS((void));
double  power ARGS((void));
double  term ARGS((void));

#define MAXBUF 10240
char buf[MAXBUF];
char *pc;/* pointer to next input character */

int
main(argc,argv)
int argc;
char* argv[];
{

    (void)printf("expr>");
    while (fgets(buf,MAXBUF,stdin) != (char*)NULL)
    {   /* parse expressions until end-of-file */
        initialize();
        (void)printf("%g\n",expr());
        if (nextnb())
            error(); /* catch trailing garbage */
        (void)printf("expr>");
        (void)fflush(stdout);
    }

    exit (EXIT_SUCCESS);
    return (EXIT_SUCCESS);
}

void
error()
{
    (void)fprintf(stderr,
        "? Error: remaining text = [%s]\n",pc);
    *pc = '\0';
}

void
expect(c)
int c;
{
    if (nextnb() != c)
        error();
}

double
expr()
{
    double e = term();

    for (;;)
    {
        if (peeknb() == '+')    /* expr + term */
            nextnb(), e += term();
        else if (peeknb() == '-')/* expr - term */
            nextnb(), e -= term();
        else
            return (e);
    }
}

double
factor()
{
    double e;
    char *p;

    if (peeknb() == '(')        /* ( expr ) */
    {
        nextnb();
        e = expr();
        expect(')');
    }
    else                        /* number */
    {
        e = strtod(pc, &p);
        if (p == pc)
            error();
        else
            pc = p;
    }
    return (e);
}

void
initialize()
{
    pc = buf;
}

int
nextnb()
{
    while (*pc && isspace(*pc))
        ++pc;
    return (*pc ? *pc++ : *pc);
        /* don't advance beyond EOS */
}

int
peeknb()
{
    int c = nextnb();

    pc--;
    return (c);
}

double
power()
{
    double p = factor();

    for (;;)
    {
        if (peeknb() == '^')
            nextnb(), p = pow(p,power());
        else
            return (p);
    }
}


double
term()
{
    double t = power();

    for (;;)
    {
        if (peeknb() == '*')
            nextnb(), t *= power();
        else if (peeknb() == '/')
            nextnb(), t /= power();
        else
            return (t);
    }
}
