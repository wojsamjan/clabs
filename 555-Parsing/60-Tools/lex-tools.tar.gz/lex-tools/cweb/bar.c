/*1:*/
#line 5 "bar.w"






#include <math.h>
#include <stdio.h>


int
main(argc,argv)
int argc;
char*argv[];
{
int k;
double g;

for(k= 0;k<20;++k)
{
g= gamma((double)k);
printf("gamma(%d) = %lg",k,g);
g= signgam*exp(g);
printf(" %lg\n",g);
}

return(0);
}/*:1*/
