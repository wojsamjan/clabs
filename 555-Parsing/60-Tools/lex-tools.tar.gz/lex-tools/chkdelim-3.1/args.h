/* /u/sy/beebe/src/lex/chkdelim-new/args.h, Fri Dec 22 11:28:57 1995 */
/* Edit by Nelson H. F. Beebe <beebe@plot79.math.utah.edu> */

#if (defined(__cplusplus) || defined(__STDC__) || defined(c_plusplus))
#define ARGS(plist)	plist
#define NEW_STYLE 1
#define VOID	void
#include <stdlib.h>
#else
#define ARGS(plist)	()
#define NEW_STYLE 0
#define VOID
#define const
#endif

#if !defined(EXIT_SUCCESS)
#define EXIT_SUCCESS	0
#define EXIT_FAILURE	1
#endif
