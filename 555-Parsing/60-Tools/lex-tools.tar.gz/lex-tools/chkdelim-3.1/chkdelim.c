#include <stdio.h>
# define U(x) x
# define NLSTATE yyprevious=YYNEWLINE
# define BEGIN yybgin = yysvec + 1 +
# define INITIAL 0
# define YYLERR yysvec
# define YYSTATE (yyestate-yysvec-1)
# define YYOPTIM 1
# define YYLMAX BUFSIZ
#ifndef __cplusplus
# define output(c) (void)putc(c,yyout)
#else
# define lex_output(c) (void)putc(c,yyout)
#endif

#if defined(__cplusplus) || defined(__STDC__)

#if defined(__cplusplus) && defined(__EXTERN_C__)
extern "C" {
#endif
	int yyback(int *, int);
	int yyinput(void);
	int yylook(void);
	void yyoutput(int);
	int yyracc(int);
	int yyreject(void);
	void yyunput(int);
	int yylex(void);
#ifdef YYLEX_E
	void yywoutput(wchar_t);
	wchar_t yywinput(void);
#endif
#ifndef yyless
	void yyless(int);
#endif
#ifndef yywrap
	int yywrap(void);
#endif
#ifdef LEXDEBUG
	void allprint(char);
	void sprint(char *);
#endif
#if defined(__cplusplus) && defined(__EXTERN_C__)
}
#endif

#ifdef __cplusplus
extern "C" {
#endif
	void exit(int);
#ifdef __cplusplus
}
#endif

#endif
# define unput(c) {yytchar= (c);if(yytchar=='\n')yylineno--;*yysptr++=yytchar;}
# define yymore() (yymorfg=1)
#ifndef __cplusplus
# define input() (((yytchar=yysptr>yysbuf?U(*--yysptr):getc(yyin))==10?(yylineno++,yytchar):yytchar)==EOF?0:yytchar)
#else
# define lex_input() (((yytchar=yysptr>yysbuf?U(*--yysptr):getc(yyin))==10?(yylineno++,yytchar):yytchar)==EOF?0:yytchar)
#endif
#define ECHO fprintf(yyout, "%s",yytext)
# define REJECT { nstr = yyreject(); goto yyfussy;}
int yyleng; extern char yytext[];
int yymorfg;
extern char *yysptr, yysbuf[];
int yytchar;
FILE *yyin = {stdin}, *yyout = {stdout};
extern int yylineno;
struct yysvf { 
	struct yywork *yystoff;
	struct yysvf *yyother;
	int *yystops;};
struct yysvf *yyestate;
extern struct yysvf yysvec[], *yybgin;

# line 2 "chkdelim.l"
 /**********************************************************************
 @Lex-file{
    author              = "Nelson H. F. Beebe",
    version             = "3.1",
    date                = "29 January 1996",
    time                = "14:11:53 MST",
    filename            = "chkdelim.l",
    address             = "Center for Scientific Computing
			   Department of Mathematics
			   University of Utah
			   Salt Lake City, UT 84112
			   USA",
    telephone           = "+1 801 581 5254",
    FAX                 = "+1 801 581 4148",
    checksum            = "28418 930 2626 20693",
    email               = "beebe@math.utah.edu (Internet)",
    codetable           = "ISO/ASCII",
    keywords            = "delimiter check",
    supported           = "yes",
    docstring           = "This program checks for balanced delimiters
			   (braces, angle brackets, parentheses,
			   square brackets, TeX dollars) on stdin.

			   chkdelim returns a successful status code
			   (0 on UNIX) if no errors were found, and
			   otherwise, returns an unsuccessful status
			   code (1 on UNIX).

			   Usage:
			       chkdelim [-?] [-author] [-copyright]
			       		[-help] [-ignore "delimiters"]
			                [-noTeX] [-noparagraph] [-paragraph]
			                [-TeX] [-version] [files] >outfile

			   The -? and -help options give a brief help
			   display on stderr, and then execution
			   terminates.

			   The -author, -copyright, and -version
			   options display author, copyright, and
			   version information on stderr, and
			   execution continues.

			   Selected delimiters will be ignored if
			   specified as a separate argument on the
			   command line following an -ignore option.
			   Either, or both, open and close delimiters
			   may be specified, e.g. -ignore (), -ignore
			   (, and -ignore ) are equivalent.  Each
			   -ignore option causes settings from
			   previous -ignore options to be discarded.

			   The -paragraph option requests that at end
			   of paragraph, which is a line that is
			   empty, or contains only whitespace, chdelim
			   should issue any needed error messages, and
			   then forget any delimiter imbalances.  This
			   option is often useful to limit the number
			   of error messages that can appear.

			   The -noparagraph option reversed the effect
			   of a previous -paragraph option.

			   The -TeX option turns on dollar sign
			   recognition, and makes grave and acute
			   accents pair with each other.

			   The -noTeX option reverses the effect of a
			   previous -TeX option: dollar signs are
			   ignored, and grave and acute accents pair
			   with themselves, like quotation marks do.

			   Only enough characters need to be specified
			   on option names to make them unique, and
			   letter case is NOT significant.

			   Switches affects ONLY those files which
			   follow it on the command line.

			   NB: This version of chkdelim cannot be used
			   with GNU flex, just with UNIX lex.  The
			   reason is that flex does not permit
			   redefinition of input() and unput(), and
			   the current implementation of chkdelim
			   requires private versions of both those
			   functions.

			   This code cannot be compiled with C++
			   compilers on DEC Alpha OSF/1, DEC ULTRIX
			   4.3, HP HP-UX 10.0, Sun SunOS 4.x, Sun
			   Solaris 2.x, and possibly others, because
			   of errors and anachronisms in the
			   vendor-supplied lex template code.  On HP
			   HP-UX 10.0, c89 cannot be used either,
			   because the lex template code incorrectly
			   invokes main() with no arguments.

			   C++ compilation works on IBM RS/6000 AIX
			   3.2.5 and SGI IRIX 5.3.

			   Successful builds on:
				DEC Alpha OSF/1 3.0: cc, c89, gcc
				DEC ULTRIX 4.3: cc, gcc, lcc
				IBM RS/6000 AIX 3.2.5: cc, c89, gcc, xlC
				NeXT Mach 3.0: cc, gcc
				SGI IRIX 5.3: cc, gcc, CC, g++
				Sun SunOS 4.1.3: acc, cc, gcc, lcc
				Sun Solaris 2.3: cc, gcc, lcc

			   Builds on SGI IRIX 6.0.1 failed with cc,
			   CC, gcc, and g++ because of errors in
			   libraries or template code.

                           TO DO: Handle Spanish inverted ! and ?,
                           French guillemets << >>, and their TeX
                           macro equivalents.

			   The checksum field above contains a CRC-16
			   checksum as the first value, followed by the
			   equivalent of the standard UNIX wc (word
			   count) utility output of lines, words, and
			   characters.  This is produced by Robert
			   Solovay's checksum utility.",
 }
 **********************************************************************/

# line 127 "chkdelim.l"
/* -*-C-*- chkdelim - check delimiter balance */

# line 128 "chkdelim.l"
/* /u/sy/beebe/src/lex/chkdelim/chkdelim.l, Wed Apr 24 17:44:22 1991 */

# line 129 "chkdelim.l"
/* Edit by Nelson H.F. Beebe <beebe@plot79.math.utah.edu> */

#define PROGRAM "chkdelim"
#define VERSION "3.1 [29-Jan-1996]"	/* NB: remember to change this! */

#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include "args.h"

typedef int Boolean;

#ifdef MAX
#undef MAX
#endif
#define MAX(a,b)	(((a) > (b)) ? (a) : (b))

#ifdef FALSE
#undef FALSE
#endif
#define FALSE	0

#ifdef TRUE
#undef TRUE
#endif
#define TRUE	1

#undef input
#undef unput
#undef yywrap		/* in case we use flex instead of lex */

typedef struct
{
    long nc;				/* character number in file */
    long nl;				/* line number in file */
    long ncl;				/* character number in line */
} Pos;

static Pos current = {
    0, 1, 0,
};

static Pos last_newline = {
    0, 0, 0,
};

#define ARGEQUAL(s,t,n)	(strnicmp((s),(t),MAX((n),(int)strlen(s))) == 0)
#define	ERROR_PREFIX	"??"	/* this prefixes all error messages */
#define MAXBUF		2048		/* pushback buffer size */
#define MAXDISPLAYLINES	10		/* maximum display math lines */
#define MAXPOS		512		/* maximum nesting of () [] {} <> */

static const char *	the_filename = "";
static const char *	program_name = PROGRAM;

static long		error_count = 0L;
static Boolean		ignore_angle = FALSE;
static Boolean		ignore_brace = FALSE;
static Boolean		ignore_dollar = TRUE; /* NB: $...$ only in -TeX mode */
static Boolean		ignore_paren = FALSE;
static Boolean		ignore_square = FALSE;
static Boolean		ignore_grave = FALSE;
static Boolean		ignore_acute = FALSE;
static Boolean		ignore_quote = FALSE;
static int 		input_n = 0;
static int 		input_buf[MAXBUF];

static int 		ndollar = 0;
static Pos 		dollar[MAXPOS];

static int 		ndollardollar = 0;
static Pos 		dollardollar[MAXPOS];

static int 		nacute = 0;
static Pos 		acute[MAXPOS];

static int 		nangle = 0;
static Pos 		angle[MAXPOS];

static int 		nbrace = 0;
static Pos		brace[MAXPOS];	/* static so we get pre-zeroing */

static int 		ngrave = 0;
static Pos 		grave[MAXPOS];

static int 		nparen = 0;
static Pos 		paren[MAXPOS];

static int 		nquote = 0;
static Pos 		quote[MAXPOS];

static int 		nsquare = 0;
static Pos 		square[MAXPOS];

static Boolean		paragraph_reset = FALSE;

static Boolean		TeX_quotes = FALSE;

extern int		strnicmp ARGS((const char *s1_, const char *s2_,
				       size_t n_));

int			main ARGS((int argc_, char *argv_[]));
int			yywrap ARGS((void));

static void		check_balance ARGS((void));
static void		dec ARGS((Pos *, int *));
static void		display_math ARGS((void));
static void		do_acute ARGS((void));
static void		do_file ARGS((void));
static void		do_grave ARGS((void));
static void		do_quote ARGS((void));
static void		dump ARGS((Pos *, int, const char *));
static void		empty_line ARGS((void));
static void		ignore ARGS((const char *delimiters));
static void		inc ARGS((Pos *, int *));
static void		inline_math ARGS((void));

#if defined(__cplusplus) || defined(c_plusplus)
#undef lex_input
#define input		lex_input
#endif

static int		input ARGS((void));
static void		opt_author ARGS((void));
static void		opt_copyright ARGS((void));
static void		opt_help ARGS((void));
static void		opt_noTeX ARGS((void));
static void		opt_noparagraph ARGS((void));
static void		opt_paragraph ARGS((void));
static void		opt_TeX ARGS((void));
static void		opt_usage ARGS((const char *bad_option));
static void		opt_version ARGS((void));
static void		out_lines ARGS((FILE *fpout_, const char *lines_[]));
static char*		position ARGS((Pos *p));
static void		print_id ARGS((Pos *p, char *fmt, const char *arg));
static void		too_few ARGS((Pos *, int));
static void		too_many ARGS((Pos *, int));
static void		unput ARGS((int));

# define YYNEWLINE 10
yylex(){
int nstr; extern int yyprevious;
#ifdef __cplusplus
/* to avoid CC and lint complaining yyfussy not being used ...*/
static int __lex_hack = 0;
if (__lex_hack) goto yyfussy;
#endif
while((nstr = yylook()) >= 0)
yyfussy: switch(nstr){
case 0:
if(yywrap()) return(0); break;
case 1:

# line 274 "chkdelim.l"
		;
break;
case 2:

# line 276 "chkdelim.l"
;
break;
case 3:

# line 278 "chkdelim.l"
	if (!ignore_dollar) display_math();
break;
case 4:

# line 280 "chkdelim.l"
	if (!ignore_dollar) inline_math();
break;
case 5:

# line 282 "chkdelim.l"
if (!TeX_quotes) yyless(1);
break;
case 6:

# line 284 "chkdelim.l"
	if (!ignore_acute) do_acute();
break;
case 7:

# line 286 "chkdelim.l"
	if (!ignore_grave) do_grave();
break;
case 8:

# line 288 "chkdelim.l"
	if (!ignore_quote) do_quote();
break;
case 9:

# line 290 "chkdelim.l"
	if (!ignore_brace) inc(brace,&nbrace);
break;
case 10:

# line 292 "chkdelim.l"
	if (!ignore_brace) dec(brace,&nbrace);
break;
case 11:

# line 294 "chkdelim.l"
	if (!ignore_square) inc(square,&nsquare);
break;
case 12:

# line 296 "chkdelim.l"
	if (!ignore_square) dec(square,&nsquare);
break;
case 13:

# line 298 "chkdelim.l"
	if (!ignore_angle) inc(angle,&nangle);
break;
case 14:

# line 300 "chkdelim.l"
	if (!ignore_angle) dec(angle,&nangle);
break;
case 15:

# line 302 "chkdelim.l"
	if (!ignore_paren) inc(paren,&nparen);
break;
case 16:

# line 304 "chkdelim.l"
	if (!ignore_paren) dec(paren,&nparen);
break;
case 17:

# line 306 "chkdelim.l"
empty_line();
break;
case 18:

# line 308 "chkdelim.l"
case 19:

# line 309 "chkdelim.l"
	;
break;
case -1:
break;
default:
(void)fprintf(yyout,"bad switch yylook %d",nstr);
} return(0); }
/* end of yylex */

static void
check_balance(VOID)
{
    if (TeX_quotes)
    {
        if (!ignore_grave) dump(grave,ngrave,"`"); /* "`" for balance */
    }
    else
    {
	if (!ignore_acute) dump(acute,nacute,"'"); /* "'" for balance */
	if (!ignore_grave) dump(grave,ngrave,"`"); /* "`" for balance */
    }
    if (!ignore_dollar) dump(dollar,ndollar,"$"); /* "$" for balance */
    if (!ignore_dollar) dump(dollardollar,ndollardollar,"$$");
					/* "$$" for balance */
    if (!ignore_quote)  dump(quote,nquote,"\""); /* "\"" for balance */
    if (!ignore_angle)  dump(angle,nangle,"<");	/* ">" for balance */
    if (!ignore_brace)  dump(brace,nbrace,"{");	/* "}" for balance */
    if (!ignore_paren)	dump(paren,nparen,"(");	/* ")" for balance */
    if (!ignore_square)	dump(square,nsquare,"["); /* "]" for balance */
}

static void
#if NEW_STYLE
dec(
Pos* a,
int *n
)
#else /* NOT NEW_STYLE */
dec(a,n)
Pos* a;
int *n;
#endif /* NEW_STYLE */
{
    if (*n > 0)
	(*n)--;
    else
	too_few(a,*n);
}


static void
display_math(VOID)
{
    if ((ndollardollar % 2) == 0)	/* expect open delimiter */
    {
	if ((ndollardollar >= 0) && (ndollardollar < MAXPOS))
	    dollardollar[ndollardollar++] = current;
	else
	    too_many(dollardollar,ndollardollar);
    }
    else				/* expect close delimiter */
    {
	if (ndollardollar > 0)
	{
	    ndollardollar--;
	    if (current.nl >
		(dollardollar[ndollardollar].nl + MAXDISPLAYLINES))
		print_id(&current,
			 "Long display math environment began at %s\n",
			 (const char*)position(&dollardollar[ndollardollar]));
	}
	else
	    too_few(dollardollar,ndollardollar);
    }
}


static void
do_acute(VOID)
{
    if (TeX_quotes)
        dec(grave, &ngrave);
    else if ((nacute % 2) == 0)		/* expect open delimiter */
    {
	if ((nacute >= 0) && (nacute < MAXPOS))
	    acute[nacute++] = current;
	else
	    too_many(acute,nacute);
    }
    else				/* expect close delimiter */
    {
	if (nacute > 0)
	{
	    nacute--;
	    if (current.nl > acute[nacute].nl)
		print_id(&current, "Multi-line '...string...' began at %s\n",
			 (const char*)position(&acute[nacute]));
	}
	else
	    too_few(acute,nacute);
    }
}


static void
do_file(VOID)
{
    while (yylex() > 0)
	/* NO-OP */;
}


static void
do_grave(VOID)
{
    if (TeX_quotes)
        inc(grave, &ngrave);
    else if ((ngrave % 2) == 0)		/* expect open delimiter */
    {
	if ((ngrave >= 0) && (ngrave < MAXPOS))
	    grave[ngrave++] = current;
	else
	    too_many(grave,ngrave);
    }
    else				/* expect close delimiter */
    {
	if (ngrave > 0)
	{
	    ngrave--;
	    if (current.nl > grave[ngrave].nl)
		print_id(&current, "Multi-line `...string...` began at %s\n",
			 (const char*)position(&grave[ngrave]));
	}
	else
	    too_few(grave,ngrave);
    }
}


static void
do_quote(VOID)
{
    if ((nquote % 2) == 0)		/* expect open delimiter */
    {
	if ((nquote >= 0) && (nquote < MAXPOS))
	    quote[nquote++] = current;
	else
	    too_many(quote,nquote);
    }
    else				/* expect close delimiter */
    {
	if (nquote > 0)
	{
	    nquote--;
	    if (current.nl > quote[nquote].nl)
		print_id(&current, "Multi-line \"...string...\" began at %s\n",
			 (const char*)position(&quote[nquote]));
	}
	else
	    too_few(quote,nquote);
    }
}


static void
#if NEW_STYLE
dump(
Pos* a,
int n,
const char *s
)
#else /* NOT NEW_STYLE */
dump(a,n,s)			/* show unmatched delimiter positions */
Pos* a;
int n;
const char *s;
#endif /* NEW_STYLE */
{
    int k;

    for (k = 0; k < n; ++k)
	print_id(&a[k], "Unmatched delimiter %s\n", s);
}


static void
empty_line(VOID)
{
    if (ndollardollar % 2)
	print_id(&current, "Empty line in display math mode\n", "");
    if (paragraph_reset)
    {
	check_balance();
	nacute = 0;
	nangle = 0;
	nbrace = 0;
	ndollar = 0;
	ndollardollar = 0;
	ngrave = 0;
	nparen = 0;
	nquote = 0;
	nsquare = 0;
    }
}


static void
#if NEW_STYLE
ignore(
const char *delimiters
)
#else /* NOT NEW_STYLE */
ignore(delimiters)
const char *delimiters;
#endif /* NEW_STYLE */
{

#define is_set(x) ((strchr(delimiters,x) == (const char*)NULL) ? FALSE : TRUE)

    ignore_angle  = is_set('<') || is_set('>');
    ignore_brace  = is_set('{') || is_set('}');
    ignore_paren  = is_set('(') || is_set(')');
    ignore_square = is_set('[') || is_set(']');

    ignore_acute  = is_set('\'');	/* '\'' for balance */
    ignore_dollar = is_set('$');	/* '$' for balance */
    ignore_grave  = is_set('`');	/* '`' for balance */
    ignore_quote  = is_set('"');	/* '"' for balance */

    if (TeX_quotes)
        ignore_acute = ignore_grave = (ignore_acute || ignore_grave);
}


static void
#if NEW_STYLE
inc(
Pos* a,
int *n
)
#else /* NOT NEW_STYLE */
inc(a,n)
Pos* a;
int *n;
#endif /* NEW_STYLE */
{
    if ((*n >= 0) && (*n < MAXPOS))
	a[(*n)++] = current;
    else
	too_many(a,*n);
}


static void
inline_math(VOID)
{
    if ((ndollar % 2) == 0)		/* expect open delimiter */
    {
	if ((ndollar >= 0) && (ndollar < MAXPOS))
	    dollar[ndollar++] = current;
	else
	    too_many(dollar,ndollar);
    }
    else				/* expect close delimiter */
    {
	if (ndollar > 0)
	{
	    ndollar--;
	    if (current.nl > dollar[ndollar].nl)
		print_id(&current, "Multi-line inline math began at %s\n",
			 (const char*)position(&dollar[ndollar]));
	}
	else
	    too_few(dollar,ndollar);
    }
}


static int
input(VOID)
{
    int c;

    if (input_n > 0)
	c = input_buf[--input_n];
    else
	c = getchar();
    if (c == '\n')
    {
	last_newline = current;		/* remember for restore in unput() */
	current.nl++;
	current.ncl = 0;
    }
    else
	current.ncl++;
    current.nc++;
    return (c == EOF) ? 0 : c;
}


#if NEW_STYLE
int
main(int argc, char *argv[])
#else /* K&R style */
int
main(argc, argv)
int argc;
char *argv[];
#endif /* NEW_STYLE */
{
    int file_count;
    int k;
    FILE *fp;

    program_name = argv[0];

    ignore("$");		/* initially only dollar ignored */

    file_count = 0;
    for (k = 1; k < argc; ++k)
    {
	if (ARGEQUAL(argv[k],"-author",2))
	    opt_author();
	else if (ARGEQUAL(argv[k],"-copyright",2))
	    opt_copyright();
	else if (ARGEQUAL(argv[k],"-help",2) || ARGEQUAL(argv[k],"-?",2))
	{
	    opt_help();
	    exit (EXIT_SUCCESS);
	}
	else if (ARGEQUAL(argv[k],"-ignore",2))
	    ignore(argv[++k]);
	else if (ARGEQUAL(argv[k],"-noTeX",2))
	    opt_noTeX();
	else if (ARGEQUAL(argv[k],"-noparagraph",2))
	    opt_noparagraph();
	else if (ARGEQUAL(argv[k],"-paragraph",2))
	    opt_paragraph();
	else if (ARGEQUAL(argv[k],"-TeX",2))
	    opt_TeX();
	else if (ARGEQUAL(argv[k],"-version",2))
	    opt_version();
	else if (argv[k][0] == '-')
	{
	    opt_usage(argv[k]);
	    exit (EXIT_FAILURE);
	}
	else
	{
	    file_count++;
	    fp = freopen(argv[k],"r",stdin);
	    if (fp == (FILE*)NULL)
	    {
		(void)fprintf(stderr,
		    "\n%s Ignoring open failure on file [%s]\n",
		    ERROR_PREFIX, argv[k]);
		(void)perror("perror() says");
	    }
	    else
	    {
		the_filename = argv[k];
		do_file();
		(void)fclose(fp);
	    }
	}
    }
    if (file_count == 0)		/* unlex stdin */
    {
	the_filename = "stdin";
	do_file();
    }
    exit ((error_count > 0) ? EXIT_FAILURE : EXIT_SUCCESS);
    return (0);				/* NOT REACHED */
}


static void
opt_author(VOID)
{
    static const char *author_text[] =
    {
	"Author:\n",
	"\tNelson H. F. Beebe, Ph.D.\n",
	"\tCenter for Scientific Computing\n",
	"\tDepartment of Mathematics\n",
	"\tUniversity of Utah\n",
	"\tSalt Lake City, UT 84112\n",
	"\tUSA\n",
	"\tTel: +1 801 581 5254\n",
	"\tFAX: +1 801 581 4801\n",
	"\tEmail: <beebe@math.utah.edu>\n",
	"\tWWW URL: http://www.math.utah.edu/~beebe\n",
	"\n",
	(const char*)NULL,
    };

    out_lines(stderr, author_text);
}


static void
opt_copyright(VOID)
{
    static const char *copyright_text[] =
    {
        "Copyright: none\n",
	"\t*********************************************\n",
	"\t*********************************************\n",
	"\t*** This program is in the PUBLIC DOMAIN. ***\n",
	"\t*********************************************\n",
	"\t*********************************************\n",
	"\n",
	(const char*)NULL,
    };
    out_lines(stderr, copyright_text);
}


static void
opt_help(VOID)
{
    static const char *help_text[] =
    {
        "On UNIX systems, try\n",
	"\tman ", PROGRAM, "\n",
	"for a detailed description.\n",
	"\n",
	(const char*)NULL,
    };

    opt_usage((const char*)NULL);
    out_lines(stderr, help_text);
    opt_author();
    opt_copyright();
}


static void
opt_noparagraph(VOID)
{
    paragraph_reset = FALSE;
}


static void
opt_noTeX(VOID)
{
    ignore_dollar = TRUE;
    TeX_quotes = FALSE;
}


static void
opt_paragraph(VOID)
{
    paragraph_reset = TRUE;
}


static void
opt_TeX(VOID)
{
    ignore_dollar = FALSE;
    TeX_quotes = TRUE;
}


static void
#if NEW_STYLE
opt_usage(const char *bad_option)
#else /* NOT NEW_STYLE */
opt_usage(bad_option)
const char *bad_option;
#endif /* NEW_STYLE */
{
    opt_version();
    if (bad_option != (const char*)NULL)
	(void)fprintf(stderr, "Unrecognized option [%s]\n", bad_option);
    (void)fprintf(stderr, "Usage:\n");
    (void)fprintf(stderr, "\t%s %s\n\t\t%s\n\t\t%s\n\t\t%s\n\n",
		  program_name,
		  "[-?] [-author] [-copyright] [-help]",
		  "[-ignore delimiters] [-noparagraph]",
		  "[-paragraph] [-noTeX] [-TeX] [-version]",
		  "[files or <infile] [>outfile]");
}


static void
opt_version(VOID)
{
    static const char *version_text[] =
    {
        "This is ", PROGRAM, " version ", VERSION, "\n",
	"\n",
	(const char *)NULL,
    };

    out_lines(stderr, version_text);
}


#if NEW_STYLE
static void
out_lines(FILE *fpout, const char *lines[])
#else
static void
out_lines(fpout, lines)
FILE *fpout;
const char *lines[];
#endif
{
    int	k;

    for (k = 0; lines[k] != (const char*)NULL; k++)
	(void)fputs(lines[k], fpout);
}


static char *
#if NEW_STYLE
position(
Pos *p
)
#else /* NOT NEW_STYLE */
position(p)
Pos *p;
#endif /* NEW_STYLE */
{
#define MAXMSG 80

    static char msg[MAXMSG];		/* preserved across calls! */

    (void)sprintf(msg, "line %ld column %ld file position %ld",
		  p->nl, p->ncl, p->nc);
    return (&msg[0]);
}


static void
#if NEW_STYLE
print_id(
Pos *p,
char *fmt,
const char *arg
)
#else /* NOT NEW_STYLE */
print_id(p,fmt,arg)
Pos *p;
char *fmt;
const char *arg;
#endif /* NEW_STYLE */
{
    error_count++;

    /* The particular form of location identification here is chosen
       to be recognizable by GNU Emacs next-error (C-x grave) command. */
    (void)printf("%s:%ld:(%ld):%ld:", the_filename, p->nl, p->ncl - 1, p->nc);
    if (fmt != (char*)NULL)
	(void)printf(fmt, arg);
}


static void
#if NEW_STYLE
too_few(
Pos *a,
int n
)
#else /* NOT NEW_STYLE */
too_few(a,n)
Pos *a;
int n;
#endif /* NEW_STYLE */
{
    print_id(&current, "Unbalanced close delimiter %s\n",
	     (const char*)&yytext[0]);
}


static void
#if NEW_STYLE
too_many(
Pos *a,
int n
)
#else /* NOT NEW_STYLE */
too_many(a,n)
Pos *a;
int n;
#endif /* NEW_STYLE */
{
    print_id(&current, "Excessive open delimiters %s\n",
	     (const char*)&yytext[0]);
    (void)printf("\t\tLast remembered open delimiter at %s\n",
		 position(&a[n-1]));
}


static void
#if NEW_STYLE
unput(int c)
#else /* NOT NEW_STYLE */
unput(c)
int c;
#endif /* NEW_STYLE */
{
    if (input_n < MAXBUF)
    {
	input_buf[input_n++] = c;
	if (c == '\n')			/* this works as long as lookahead */
	    current = last_newline;	/* is never more than one newline */
	else
	{
	    current.ncl--;
	    current.nc--;
	}
    }
}


int
yywrap(VOID)
{
    check_balance();
    return (1);				/* all done */
}
int yyvstop[] = {
0,

19,
0,

18,
0,

8,
19,
0,

4,
19,
0,

6,
19,
0,

15,
19,
0,

16,
19,
0,

19,
0,

13,
19,
0,

14,
19,
0,

11,
19,
0,

19,
0,

12,
19,
0,

7,
19,
0,

9,
19,
0,

10,
19,
0,

17,
0,

3,
0,

2,
0,

5,
0,

1,
0,
0};
# define YYTYPE unsigned char
struct yywork { YYTYPE verify, advance; } yycrank[] = {
0,0,	0,0,	1,3,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	1,3,	1,4,	
0,0,	4,19,	4,20,	0,0,	
4,19,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	1,5,	
4,19,	1,6,	6,21,	0,0,	
1,7,	1,8,	1,9,	2,6,	
10,22,	24,26,	0,0,	2,8,	
2,9,	1,10,	14,23,	0,0,	
14,23,	0,0,	0,0,	14,23,	
14,23,	14,23,	14,24,	0,0,	
0,0,	1,11,	0,0,	1,12,	
0,0,	0,0,	0,0,	2,11,	
0,0,	2,12,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
14,23,	0,0,	14,23,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
1,13,	1,14,	1,15,	0,0,	
0,0,	1,16,	2,13,	2,14,	
2,15,	0,0,	0,0,	2,16,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
14,23,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
1,17,	0,0,	1,18,	0,0,	
0,0,	0,0,	2,17,	0,0,	
2,18,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	14,23,	
0,0,	14,23,	22,25,	22,25,	
22,25,	22,25,	22,25,	22,25,	
22,25,	22,25,	22,25,	22,25,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	22,25,	
22,25,	22,25,	22,25,	22,25,	
22,25,	22,25,	22,25,	22,25,	
22,25,	22,25,	22,25,	22,25,	
22,25,	22,25,	22,25,	22,25,	
22,25,	22,25,	22,25,	22,25,	
22,25,	22,25,	22,25,	22,25,	
22,25,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	22,25,	
22,25,	22,25,	22,25,	22,25,	
22,25,	22,25,	22,25,	22,25,	
22,25,	22,25,	22,25,	22,25,	
22,25,	22,25,	22,25,	22,25,	
22,25,	22,25,	22,25,	22,25,	
22,25,	22,25,	22,25,	22,25,	
22,25,	0,0,	0,0,	0,0,	
0,0};
struct yysvf yysvec[] = {
0,	0,	0,
yycrank+-1,	0,		0,	
yycrank+-7,	yysvec+1,	0,	
yycrank+0,	0,		yyvstop+1,
yycrank+4,	0,		yyvstop+3,
yycrank+0,	0,		yyvstop+5,
yycrank+2,	0,		yyvstop+8,
yycrank+0,	0,		yyvstop+11,
yycrank+0,	0,		yyvstop+14,
yycrank+0,	0,		yyvstop+17,
yycrank+5,	0,		yyvstop+20,
yycrank+0,	0,		yyvstop+22,
yycrank+0,	0,		yyvstop+25,
yycrank+0,	0,		yyvstop+28,
yycrank+16,	0,		yyvstop+31,
yycrank+0,	0,		yyvstop+33,
yycrank+0,	0,		yyvstop+36,
yycrank+0,	0,		yyvstop+39,
yycrank+0,	0,		yyvstop+42,
yycrank+0,	yysvec+4,	0,	
yycrank+0,	0,		yyvstop+45,
yycrank+0,	0,		yyvstop+47,
yycrank+94,	0,		0,	
yycrank+0,	0,		yyvstop+49,
yycrank+5,	0,		0,	
yycrank+0,	0,		yyvstop+51,
yycrank+0,	0,		yyvstop+53,
0,	0,	0};
struct yywork *yytop = yycrank+216;
struct yysvf *yybgin = yysvec+1;
char yymatch[] = {
  0,   1,   1,   1,   1,   1,   1,   1, 
  1,   9,  10,   1,   9,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  9,   1,  34,   1,  34,   1,   1,  39, 
 34,  34,   1,   1,   1,   1,   1,   1, 
 48,  48,  48,  48,  48,  48,  48,  48, 
 48,  48,   1,   1,  34,   1,  34,   1, 
  1,  48,  48,  48,  48,  48,  48,  48, 
 48,  48,  48,  48,  48,  48,  48,  48, 
 48,  48,  48,  48,  48,  48,  48,  48, 
 48,  48,  48,   1,   1,   1,   1,   1, 
 34,  48,  48,  48,  48,  48,  48,  48, 
 48,  48,  48,  48,  48,  48,  48,  48, 
 48,  48,  48,  48,  48,  48,  48,  48, 
 48,  48,  48,  34,   1,  34,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
0};
char yyextra[] = {
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0};
/*	Copyright (c) 1989 AT&T	*/
/*	  All Rights Reserved  	*/

/*	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF AT&T	*/
/*	The copyright notice above does not evidence any   	*/
/*	actual or intended publication of such source code.	*/

#pragma ident	"@(#)ncform	6.7	93/06/07 SMI"

int yylineno =1;
# define YYU(x) x
# define NLSTATE yyprevious=YYNEWLINE
char yytext[YYLMAX];
struct yysvf *yylstate [YYLMAX], **yylsp, **yyolsp;
char yysbuf[YYLMAX];
char *yysptr = yysbuf;
int *yyfnd;
extern struct yysvf *yyestate;
int yyprevious = YYNEWLINE;
#if defined(__cplusplus) || defined(__STDC__)
int yylook(void)
#else
yylook()
#endif
{
	register struct yysvf *yystate, **lsp;
	register struct yywork *yyt;
	struct yysvf *yyz;
	int yych, yyfirst;
	struct yywork *yyr;
# ifdef LEXDEBUG
	int debug;
# endif
	char *yylastch;
	/* start off machines */
# ifdef LEXDEBUG
	debug = 0;
# endif
	yyfirst=1;
	if (!yymorfg)
		yylastch = yytext;
	else {
		yymorfg=0;
		yylastch = yytext+yyleng;
		}
	for(;;){
		lsp = yylstate;
		yyestate = yystate = yybgin;
		if (yyprevious==YYNEWLINE) yystate++;
		for (;;){
# ifdef LEXDEBUG
			if(debug)fprintf(yyout,"state %d\n",yystate-yysvec-1);
# endif
			yyt = yystate->yystoff;
			if(yyt == yycrank && !yyfirst){  /* may not be any transitions */
				yyz = yystate->yyother;
				if(yyz == 0)break;
				if(yyz->yystoff == yycrank)break;
				}
#ifndef __cplusplus
			*yylastch++ = yych = input();
#else
			*yylastch++ = yych = lex_input();
#endif
			if(yylastch > &yytext[YYLMAX]) {
				fprintf(yyout,"Input string too long, limit %d\n",YYLMAX);
				exit(1);
			}
			yyfirst=0;
		tryagain:
# ifdef LEXDEBUG
			if(debug){
				fprintf(yyout,"char ");
				allprint(yych);
				putchar('\n');
				}
# endif
			yyr = yyt;
			if ( (int)yyt > (int)yycrank){
				yyt = yyr + yych;
				if (yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transitions */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					if(lsp > &yylstate[YYLMAX]) {
						fprintf(yyout,"Input string too long, limit %d\n",YYLMAX);
						exit(1);
					}
					goto contin;
					}
				}
# ifdef YYOPTIM
			else if((int)yyt < (int)yycrank) {		/* r < yycrank */
				yyt = yyr = yycrank+(yycrank-yyt);
# ifdef LEXDEBUG
				if(debug)fprintf(yyout,"compressed state\n");
# endif
				yyt = yyt + yych;
				if(yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transitions */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					if(lsp > &yylstate[YYLMAX]) {
						fprintf(yyout,"Input string too long, limit %d\n",YYLMAX);
						exit(1);
					}
					goto contin;
					}
				yyt = yyr + YYU(yymatch[yych]);
# ifdef LEXDEBUG
				if(debug){
					fprintf(yyout,"try fall back character ");
					allprint(YYU(yymatch[yych]));
					putchar('\n');
					}
# endif
				if(yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transition */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					if(lsp > &yylstate[YYLMAX]) {
						fprintf(yyout,"Input string too long, limit %d\n",YYLMAX);
						exit(1);
					}
					goto contin;
					}
				}
			if ((yystate = yystate->yyother) && (yyt= yystate->yystoff) != yycrank){
# ifdef LEXDEBUG
				if(debug)fprintf(yyout,"fall back to state %d\n",yystate-yysvec-1);
# endif
				goto tryagain;
				}
# endif
			else
				{unput(*--yylastch);break;}
		contin:
# ifdef LEXDEBUG
			if(debug){
				fprintf(yyout,"state %d char ",yystate-yysvec-1);
				allprint(yych);
				putchar('\n');
				}
# endif
			;
			}
# ifdef LEXDEBUG
		if(debug){
			fprintf(yyout,"stopped at %d with ",*(lsp-1)-yysvec-1);
			allprint(yych);
			putchar('\n');
			}
# endif
		while (lsp-- > yylstate){
			*yylastch-- = 0;
			if (*lsp != 0 && (yyfnd= (*lsp)->yystops) && *yyfnd > 0){
				yyolsp = lsp;
				if(yyextra[*yyfnd]){		/* must backup */
					while(yyback((*lsp)->yystops,-*yyfnd) != 1 && lsp > yylstate){
						lsp--;
						unput(*yylastch--);
						}
					}
				yyprevious = YYU(*yylastch);
				yylsp = lsp;
				yyleng = yylastch-yytext+1;
				yytext[yyleng] = 0;
# ifdef LEXDEBUG
				if(debug){
					fprintf(yyout,"\nmatch ");
					sprint(yytext);
					fprintf(yyout," action %d\n",*yyfnd);
					}
# endif
				return(*yyfnd++);
				}
			unput(*yylastch);
			}
		if (yytext[0] == 0  /* && feof(yyin) */)
			{
			yysptr=yysbuf;
			return(0);
			}
#ifndef __cplusplus
		yyprevious = yytext[0] = input();
		if (yyprevious>0)
			output(yyprevious);
#else
		yyprevious = yytext[0] = lex_input();
		if (yyprevious>0)
			lex_output(yyprevious);
#endif
		yylastch=yytext;
# ifdef LEXDEBUG
		if(debug)putchar('\n');
# endif
		}
	}
#if defined(__cplusplus) || defined(__STDC__)
int yyback(int *p, int m)
#else
yyback(p, m)
	int *p;
#endif
{
	if (p==0) return(0);
	while (*p) {
		if (*p++ == m)
			return(1);
	}
	return(0);
}
	/* the following are only used in the lex library */
#if defined(__cplusplus) || defined(__STDC__)
int yyinput(void)
#else
yyinput()
#endif
{
#ifndef __cplusplus
	return(input());
#else
	return(lex_input());
#endif
	}
#if defined(__cplusplus) || defined(__STDC__)
void yyoutput(int c)
#else
yyoutput(c)
  int c; 
#endif
{
#ifndef __cplusplus
	output(c);
#else
	lex_output(c);
#endif
	}
#if defined(__cplusplus) || defined(__STDC__)
void yyunput(int c)
#else
yyunput(c)
   int c; 
#endif
{
	unput(c);
	}
