/* dw - find duplicate words -- Standalone version in Standard C */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#if __STDC__
#define ARGS(plist)	plist
#else
#define ARGS(plist)	()
#endif

#ifndef EXIT_SUCCESS
#define EXIT_SUCCESS	0
#endif

char	last_word[1024];
char	yytext[1024];
int	yyleng;
long	last_line_number = 0L;
long	line_number = 1L;

int	get_token ARGS(());
void	make_lower ARGS(());
int	main ARGS(());
void	other ARGS(());
void	word ARGS(());

#define	T_EOF	EOF
#define	T_WORD	0
#define T_WHITE	1
#define T_OTHER	2

#define	isinitial(c)	(isalpha(c) || ((c) == '_'))
#define ismiddle(c)	(isinitial(c) || isdigit(c))

int
main()
{
    register int	token;

    last_word[0] = '\0';

    while ((token = get_token()) != T_EOF)
    {
	switch (token)
	{
	case T_WORD:
	     word();
	     break;

	case T_WHITE:
	     break;

	case T_OTHER:
	     other();
	     break;

	default:
	     break;
	}
    }
    exit (EXIT_SUCCESS);
    return (0);				/* keep optimizers happy */
}

int
get_token()
{
    register int	c;
    register char	*p;
    register int	token;

    p = yytext;
    c = getchar();
    if (c == EOF)
        token = T_EOF;
    else if (isinitial(c))
    {
	token = T_WORD;
	while  (ismiddle(c))
	{
	    *p++ = c;
	    c = getchar();
	}
	ungetc(c,stdin);		/* push back lookahead */
    }
    else if (isspace(c))		/* whitespace forms single token */
    {
	token = T_WHITE;
	while (isspace(c))
	{
	    if (c == '\n')
		line_number++;
	    *p++ = c;
	    c = getchar();
	}
	ungetc(c,stdin);		/* push back lookahead */
    }
    else				/* all other tokens are single char */
    {
	token = T_OTHER;
    }
    *p = '\0';				/* terminate token in yytext[] */
    yyleng = (int)(p - yytext);
    return (token);
}

void
make_lower()
{
    int n;
    for (n = 0; n < yyleng; ++n)
	if (isupper(yytext[n]))
	    yytext[n] = tolower(yytext[n]);
}

void
other()
{
    (void)strcpy(last_word,yytext);	/* so intervening 'words' do not */
					/* trigger output of duplicates */ 
}

void
word()
{
    make_lower();
    if (strcmp(yytext,last_word) == 0)
    {
	if (last_line_number == line_number)
	    (void)printf("%ld: %s\n",
	        line_number,yytext);
	else
	    (void)printf("%ld-%ld: %s\n",
	        last_line_number,line_number,yytext);
    }
    (void)strcpy(last_word,yytext);
    last_line_number = line_number;
}
