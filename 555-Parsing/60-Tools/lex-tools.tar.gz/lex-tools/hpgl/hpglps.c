#include <stdio.h>
# define U(x) x
# define NLSTATE yyprevious=YYNEWLINE
# define BEGIN yybgin = yysvec + 1 +
# define INITIAL 0
# define YYLERR yysvec
# define YYSTATE (yyestate-yysvec-1)
# define YYOPTIM 1
# define YYLMAX BUFSIZ
#ifndef __cplusplus
# define output(c) (void)putc(c,yyout)
#else
# define lex_output(c) (void)putc(c,yyout)
#endif

#if defined(__cplusplus) || defined(__STDC__)

#if defined(__cplusplus) && defined(__EXTERN_C__)
extern "C" {
#endif
	int yyback(int *, int);
	int yyinput(void);
	int yylook(void);
	void yyoutput(int);
	int yyracc(int);
	int yyreject(void);
	void yyunput(int);
	int yylex(void);
#ifdef YYLEX_E
	void yywoutput(wchar_t);
	wchar_t yywinput(void);
#endif
#ifndef yyless
	void yyless(int);
#endif
#ifndef yywrap
	int yywrap(void);
#endif
#ifdef LEXDEBUG
	void allprint(char);
	void sprint(char *);
#endif
#if defined(__cplusplus) && defined(__EXTERN_C__)
}
#endif

#ifdef __cplusplus
extern "C" {
#endif
	void exit(int);
#ifdef __cplusplus
}
#endif

#endif
# define unput(c) {yytchar= (c);if(yytchar=='\n')yylineno--;*yysptr++=yytchar;}
# define yymore() (yymorfg=1)
#ifndef __cplusplus
# define input() (((yytchar=yysptr>yysbuf?U(*--yysptr):getc(yyin))==10?(yylineno++,yytchar):yytchar)==EOF?0:yytchar)
#else
# define lex_input() (((yytchar=yysptr>yysbuf?U(*--yysptr):getc(yyin))==10?(yylineno++,yytchar):yytchar)==EOF?0:yytchar)
#endif
#define ECHO fprintf(yyout, "%s",yytext)
# define REJECT { nstr = yyreject(); goto yyfussy;}
int yyleng; extern char yytext[];
int yymorfg;
extern char *yysptr, yysbuf[];
int yytchar;
FILE *yyin = {stdin}, *yyout = {stdout};
extern int yylineno;
struct yysvf { 
	struct yywork *yystoff;
	struct yysvf *yyother;
	int *yystops;};
struct yysvf *yyestate;
extern struct yysvf yysvec[], *yybgin;

# line 2 "hpglps.l"
 /* hpgl.l -- lex file for parsing HPGL */

# line 3 "hpglps.l"
 /* [28-Feb-1991] */

#undef yywrap		/* in case we use flex instead of lex */

#define VERSION "HPGL to PostScript translator version 1.0 [01-Mar-1991]"

#define RELATIVE_LINES

#include <stdio.h>
#include <math.h>
#include <time.h>
#include <sys/types.h>
#include <pwd.h>			/* for passwd  */

#if __STDC__
#define ARGS(plist)	plist
#else
#define ARGS(plist)	()
#endif

#define COLOR(n)	((double)(n)/(double)MAXCOLORS)
#ifdef FALSE
#undef FALSE
#endif
#define FALSE		(0)

#define MAXCOLORS	16
#define MAXLINE		255
#define PRINTF		(void)printf

#define PLOTTER_SIZE	(16.38 * 72.0)	/* longest dimension, in bp */
#define PICTURE_SIZE	(7 * 72.0)	/* standard picture size, in bp */
#define STEPS_PER_MM	40.0	/* HP7475A 8-pen plotter has 40 steps/mm */
#define SCALE(c)	((PICTURE_SIZE/PLOTTER_SIZE) * (72/25.4) * \
			(((double)c)/STEPS_PER_MM))

#ifdef TRUE
#undef TRUE
#endif
#define TRUE		(1)

#define WNA(found,expected)	do\
    {\
	PRINTF("%%? Wrong number of arguments: found %d expected %d\n",\
	    found, expected);\
	n = 0;\
	break;\
    } while (0)

#define CMD_UNKNOWN	-1

#define CMD_ABSOLUTE	0
#define CMD_COLOR	1
#define CMD_DOWN	2
#define CMD_RELATIVE	3
#define CMD_UP		4

#define MAXVALUES 4

void	do_cmd ARGS((void));
void	do_value ARGS((void));
void	init ARGS((void));

int	absolute_coordinates = TRUE;
int	cmd = CMD_UNKNOWN;
int	initialized = FALSE;
int	n = 0;
int	path_length = 0;
int	pen_is_up = TRUE;
int	values[MAXVALUES];
int	x = 0;
int	y = 0;
int	xmax = -32767;
int	ymax = -32767;
int	xmin = 32767;
int	ymin = 32767;
    
#ifdef MAX
#undef MAX
#endif
#define MAX(a,b)	(((a) > (b)) ? (a) : (b))

#ifdef MIN
#undef MIN
#endif
#define MIN(a,b)	(((a) < (b)) ? (a) : (b))

#if !defined(_CRAY)
struct passwd	*getpwnam ARGS((char* name)); /* missing in AIX pwd.h */
#endif

int	gethostname ARGS((char *name, int namelen));
char	*getlogin ARGS((void));

# define YYNEWLINE 10
yylex(){
int nstr; extern int yyprevious;
#ifdef __cplusplus
/* to avoid CC and lint complaining yyfussy not being used ...*/
static int __lex_hack = 0;
if (__lex_hack) goto yyfussy;
#endif
while((nstr = yylook()) >= 0)
yyfussy: switch(nstr){
case 0:
if(yywrap()) return(0); break;
case 1:

# line 100 "hpglps.l"
		n = 0;
break;
case 2:

# line 102 "hpglps.l"
		n = 0;
break;
case 3:

# line 104 "hpglps.l"
	n = 0;
break;
case 4:

# line 106 "hpglps.l"
		n = 0;
break;
case 5:

# line 108 "hpglps.l"
	cmd = CMD_DOWN, n = 0;
break;
case 6:

# line 110 "hpglps.l"
	cmd = CMD_UP, n = 0;
break;
case 7:

# line 112 "hpglps.l"
	cmd = CMD_ABSOLUTE, n = 0;
break;
case 8:

# line 114 "hpglps.l"
	cmd = CMD_RELATIVE, n = 0;
break;
case 9:

# line 116 "hpglps.l"
		n = 0;
break;
case 10:

# line 118 "hpglps.l"
	cmd = CMD_COLOR, n = 0;
break;
case 11:

# line 120 "hpglps.l"
		do_value();
break;
case 12:

# line 122 "hpglps.l"
		n = 0;
break;
case 13:

# line 124 "hpglps.l"
	;
break;
case 14:

# line 126 "hpglps.l"
		{	/* comment unparsed data */
			    PRINTF("%% Unparsed: %s\n",yytext);
			    /* n = 0; */
			}
break;
case -1:
break;
default:
(void)fprintf(yyout,"bad switch yylook %d",nstr);
} return(0); }
/* end of yylex */
void
do_cmd()
{
    int		dx;
    int		dy;

    if (!initialized)
	init();
    switch (cmd)
    {
	case CMD_ABSOLUTE:
	    absolute_coordinates = TRUE;
	    break;

	case CMD_RELATIVE:
	    absolute_coordinates = FALSE;
	    break;

	case CMD_UP:
	    pen_is_up = TRUE;
	    break;

	case CMD_DOWN:
	    pen_is_up = FALSE;
	    break;

	case CMD_COLOR:
	    if (n != 1)
		WNA(n,1);
	    else
		PRINTF("%5.3f setgray\n",COLOR(values[0]));
	    n = 0;
	    return;

	default:
	    break;
    }
    if (n < 2)
        return;
    else if (n > 2)
        WNA(n,2);
    else /* n == 2 */
    {
	if (pen_is_up)
	{
	    if (path_length > 0)
		PRINTF("S\n");
	    path_length = 0;
	    PRINTF("N\n");
	}
	else
	    path_length++;

#ifdef RELATIVE_LINES
	dx = absolute_coordinates ? (values[0] - x) : values[0];
	dy = absolute_coordinates ? (values[1] - y) : values[1];
	if (pen_is_up)
            PRINTF("%d %d M\n", x + dx, y + dy);
	else
	{		/* omit zero-length steps after first point */
	    if (!((path_length >= 2) && (dx == 0) && (dy == 0)))
                PRINTF("%d %d l\n", dx, dy);
	}


#else
        PRINTF("%d %d %s\n",values[0],values[1],
	   (pen_is_up ?
	       (absolute_coordinates ? "M" : "m") :
	       (absolute_coordinates ? "L" : "l")));
#endif

	n = 0;
	x = absolute_coordinates ? values[0] : (x + values[0]);
	y = absolute_coordinates ? values[1] : (y + values[1]);
	xmax = MAX(xmax,x);
	xmin = MIN(xmin,x);
	ymax = MAX(ymax,y);
	ymin = MIN(ymin,y);
    }
}

void
do_value()
{
	if (n >= MAXVALUES)
	{
	    PRINTF("%%?? ?too many numeric values\n");
	    n = 0;
	}
	values[n++] = atoi(yytext);
	do_cmd();
}

void
init()
{
    char	buf[MAXLINE+1];
    char	hostname[MAXLINE+1];
    struct passwd	*passwdp;
    char	*personal_name;
    time_t	timeval;	/* clock value from time() for ctime() */
    char	*user_name;

    timeval = time((time_t*)NULL);
    user_name = getlogin();
    user_name = (user_name == (char*)NULL) ? "" : user_name;
    passwdp = getpwnam(user_name);
    if (passwdp != (struct passwd *)NULL)
    {
	if (passwdp->pw_gecos[0] == '&')
	    personal_name = user_name;		/* & means use login name */
	else
	    personal_name = passwdp->pw_gecos;	/* have personal name */
    }
    if (gethostname(hostname,sizeof(hostname)) == 0)
	hostname[sizeof(hostname)-1] = '\0'; /* ensure final NULL */
    else				/* no hostname available */
	hostname[0] = '\0';

    PRINTF("%%!\n");
    PRINTF("%%%% %s\n",VERSION);

#ifdef __TIME__
#ifdef __DATE__
    PRINTF("%%%% Compiled on %s %s\n",__DATE__,__TIME__);
#endif
#endif

    PRINTF("%%%% Date: %s",ctime(&timeval));
					/* "Mon Dec 24 15:44:14 MST 1990" */
    PRINTF("%%%% User: %s <%s%s%s>\n",
	personal_name,user_name,hostname[0] ? "@" : "",hostname);
    PRINTF("%%%% Directory: %s\n",getcwd(buf,sizeof(buf)));
    PRINTF("%%%% BoundingBox: (atend)\n");
    PRINTF("/C {closepath} bind def\n");
    PRINTF("/L {lineto} bind def\n");
    PRINTF("/l {rlineto} bind def\n");
    PRINTF("/M {moveto} bind def\n");
    PRINTF("/m {rmoveto} bind def\n");
    PRINTF("/N {newpath} bind def\n");
    PRINTF("/S {stroke} bind def\n");
    PRINTF("/PICTURE_SIZE {%g} def\n",PICTURE_SIZE);
    PRINTF("/PLOTTER_SIZE {%g} def\n",PLOTTER_SIZE);
    PRINTF("PICTURE_SIZE PLOTTER_SIZE div dup scale\n");
    initialized = TRUE;
}

int
yywrap()
{
    PRINTF("%%%% BoundingBox: %d %d %d %d\n",
	(int)floor(SCALE(xmin)), (int)floor(SCALE(ymin)),
	(int)ceil(SCALE(xmax)), (int)ceil(SCALE(ymax)));
    return (1);
}
int yyvstop[] = {
0,

14,
0,

13,
14,
0,

13,
0,

14,
0,

11,
14,
0,

12,
14,
0,

14,
0,

14,
-3,
0,

4,
14,
0,

14,
0,

14,
0,

1,
0,

11,
0,

2,
0,

3,
0,

-7,
0,

-5,
0,

-8,
0,

-6,
0,

9,
0,

-10,
0,

7,
0,

5,
0,

8,
0,

6,
0,

10,
0,
0};
# define YYTYPE unsigned char
struct yywork { YYTYPE verify, advance; } yycrank[] = {
0,0,	0,0,	1,3,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	1,4,	1,5,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
1,6,	2,6,	0,0,	0,0,	
0,0,	1,4,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	6,14,	
0,0,	1,7,	7,15,	7,15,	
7,15,	7,15,	7,15,	7,15,	
7,15,	7,15,	7,15,	7,15,	
1,8,	10,17,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	1,9,	2,9,	9,16,	
18,24,	12,18,	1,10,	2,10,	
12,19,	0,0,	13,22,	1,11,	
2,11,	1,12,	2,12,	10,17,	
1,13,	2,13,	0,0,	19,25,	
0,0,	0,0,	12,20,	13,23,	
0,0,	12,21,	18,24,	0,0,	
0,0,	0,0,	20,26,	10,17,	
10,17,	10,17,	10,17,	10,17,	
10,17,	10,17,	10,17,	10,17,	
10,17,	19,25,	18,24,	18,24,	
18,24,	18,24,	18,24,	18,24,	
18,24,	18,24,	18,24,	18,24,	
20,26,	0,0,	0,0,	0,0,	
21,27,	19,25,	19,25,	19,25,	
19,25,	19,25,	19,25,	19,25,	
19,25,	19,25,	19,25,	23,28,	
20,26,	20,26,	20,26,	20,26,	
20,26,	20,26,	20,26,	20,26,	
20,26,	20,26,	21,27,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	23,28,	0,0,	0,0,	
0,0,	0,0,	21,27,	21,27,	
21,27,	21,27,	21,27,	21,27,	
21,27,	21,27,	21,27,	21,27,	
0,0,	23,28,	23,28,	23,28,	
23,28,	23,28,	23,28,	23,28,	
23,28,	23,28,	23,28,	0,0,	
0,0};
struct yysvf yysvec[] = {
0,	0,	0,
yycrank+-1,	0,		0,	
yycrank+-2,	yysvec+1,	0,	
yycrank+0,	0,		yyvstop+1,
yycrank+0,	0,		yyvstop+3,
yycrank+0,	0,		yyvstop+6,
yycrank+1,	0,		yyvstop+8,
yycrank+2,	0,		yyvstop+10,
yycrank+0,	0,		yyvstop+13,
yycrank+1,	0,		yyvstop+16,
yycrank+51,	0,		yyvstop+18,
yycrank+0,	0,		yyvstop+21,
yycrank+8,	0,		yyvstop+24,
yycrank+11,	0,		yyvstop+26,
yycrank+0,	0,		yyvstop+28,
yycrank+0,	yysvec+7,	yyvstop+30,
yycrank+0,	0,		yyvstop+32,
yycrank+0,	0,		yyvstop+34,
yycrank+62,	0,		yyvstop+36,
yycrank+77,	0,		yyvstop+38,
yycrank+88,	0,		yyvstop+40,
yycrank+114,	0,		yyvstop+42,
yycrank+0,	0,		yyvstop+44,
yycrank+125,	0,		yyvstop+46,
yycrank+0,	0,		yyvstop+48,
yycrank+0,	0,		yyvstop+50,
yycrank+0,	0,		yyvstop+52,
yycrank+0,	0,		yyvstop+54,
yycrank+0,	0,		yyvstop+56,
0,	0,	0};
struct yywork *yytop = yycrank+182;
struct yysvf *yybgin = yysvec+1;
char yymatch[] = {
  0,   1,   1,   1,   1,   1,   1,   1, 
  1,   9,  10,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
 32,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   9,   1,   1,   1, 
 48,  48,  48,  48,  48,  48,  48,  48, 
 48,  48,   9,  59,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
  1,   1,   1,   1,   1,   1,   1,   1, 
0};
char yyextra[] = {
0,0,0,1,0,1,1,1,
1,0,1,0,0,0,0,0,
0};
/*	Copyright (c) 1989 AT&T	*/
/*	  All Rights Reserved  	*/

/*	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF AT&T	*/
/*	The copyright notice above does not evidence any   	*/
/*	actual or intended publication of such source code.	*/

#pragma ident	"@(#)ncform	6.7	93/06/07 SMI"

int yylineno =1;
# define YYU(x) x
# define NLSTATE yyprevious=YYNEWLINE
char yytext[YYLMAX];
struct yysvf *yylstate [YYLMAX], **yylsp, **yyolsp;
char yysbuf[YYLMAX];
char *yysptr = yysbuf;
int *yyfnd;
extern struct yysvf *yyestate;
int yyprevious = YYNEWLINE;
#if defined(__cplusplus) || defined(__STDC__)
int yylook(void)
#else
yylook()
#endif
{
	register struct yysvf *yystate, **lsp;
	register struct yywork *yyt;
	struct yysvf *yyz;
	int yych, yyfirst;
	struct yywork *yyr;
# ifdef LEXDEBUG
	int debug;
# endif
	char *yylastch;
	/* start off machines */
# ifdef LEXDEBUG
	debug = 0;
# endif
	yyfirst=1;
	if (!yymorfg)
		yylastch = yytext;
	else {
		yymorfg=0;
		yylastch = yytext+yyleng;
		}
	for(;;){
		lsp = yylstate;
		yyestate = yystate = yybgin;
		if (yyprevious==YYNEWLINE) yystate++;
		for (;;){
# ifdef LEXDEBUG
			if(debug)fprintf(yyout,"state %d\n",yystate-yysvec-1);
# endif
			yyt = yystate->yystoff;
			if(yyt == yycrank && !yyfirst){  /* may not be any transitions */
				yyz = yystate->yyother;
				if(yyz == 0)break;
				if(yyz->yystoff == yycrank)break;
				}
#ifndef __cplusplus
			*yylastch++ = yych = input();
#else
			*yylastch++ = yych = lex_input();
#endif
			if(yylastch > &yytext[YYLMAX]) {
				fprintf(yyout,"Input string too long, limit %d\n",YYLMAX);
				exit(1);
			}
			yyfirst=0;
		tryagain:
# ifdef LEXDEBUG
			if(debug){
				fprintf(yyout,"char ");
				allprint(yych);
				putchar('\n');
				}
# endif
			yyr = yyt;
			if ( (int)yyt > (int)yycrank){
				yyt = yyr + yych;
				if (yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transitions */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					if(lsp > &yylstate[YYLMAX]) {
						fprintf(yyout,"Input string too long, limit %d\n",YYLMAX);
						exit(1);
					}
					goto contin;
					}
				}
# ifdef YYOPTIM
			else if((int)yyt < (int)yycrank) {		/* r < yycrank */
				yyt = yyr = yycrank+(yycrank-yyt);
# ifdef LEXDEBUG
				if(debug)fprintf(yyout,"compressed state\n");
# endif
				yyt = yyt + yych;
				if(yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transitions */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					if(lsp > &yylstate[YYLMAX]) {
						fprintf(yyout,"Input string too long, limit %d\n",YYLMAX);
						exit(1);
					}
					goto contin;
					}
				yyt = yyr + YYU(yymatch[yych]);
# ifdef LEXDEBUG
				if(debug){
					fprintf(yyout,"try fall back character ");
					allprint(YYU(yymatch[yych]));
					putchar('\n');
					}
# endif
				if(yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transition */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					if(lsp > &yylstate[YYLMAX]) {
						fprintf(yyout,"Input string too long, limit %d\n",YYLMAX);
						exit(1);
					}
					goto contin;
					}
				}
			if ((yystate = yystate->yyother) && (yyt= yystate->yystoff) != yycrank){
# ifdef LEXDEBUG
				if(debug)fprintf(yyout,"fall back to state %d\n",yystate-yysvec-1);
# endif
				goto tryagain;
				}
# endif
			else
				{unput(*--yylastch);break;}
		contin:
# ifdef LEXDEBUG
			if(debug){
				fprintf(yyout,"state %d char ",yystate-yysvec-1);
				allprint(yych);
				putchar('\n');
				}
# endif
			;
			}
# ifdef LEXDEBUG
		if(debug){
			fprintf(yyout,"stopped at %d with ",*(lsp-1)-yysvec-1);
			allprint(yych);
			putchar('\n');
			}
# endif
		while (lsp-- > yylstate){
			*yylastch-- = 0;
			if (*lsp != 0 && (yyfnd= (*lsp)->yystops) && *yyfnd > 0){
				yyolsp = lsp;
				if(yyextra[*yyfnd]){		/* must backup */
					while(yyback((*lsp)->yystops,-*yyfnd) != 1 && lsp > yylstate){
						lsp--;
						unput(*yylastch--);
						}
					}
				yyprevious = YYU(*yylastch);
				yylsp = lsp;
				yyleng = yylastch-yytext+1;
				yytext[yyleng] = 0;
# ifdef LEXDEBUG
				if(debug){
					fprintf(yyout,"\nmatch ");
					sprint(yytext);
					fprintf(yyout," action %d\n",*yyfnd);
					}
# endif
				return(*yyfnd++);
				}
			unput(*yylastch);
			}
		if (yytext[0] == 0  /* && feof(yyin) */)
			{
			yysptr=yysbuf;
			return(0);
			}
#ifndef __cplusplus
		yyprevious = yytext[0] = input();
		if (yyprevious>0)
			output(yyprevious);
#else
		yyprevious = yytext[0] = lex_input();
		if (yyprevious>0)
			lex_output(yyprevious);
#endif
		yylastch=yytext;
# ifdef LEXDEBUG
		if(debug)putchar('\n');
# endif
		}
	}
#if defined(__cplusplus) || defined(__STDC__)
int yyback(int *p, int m)
#else
yyback(p, m)
	int *p;
#endif
{
	if (p==0) return(0);
	while (*p) {
		if (*p++ == m)
			return(1);
	}
	return(0);
}
	/* the following are only used in the lex library */
#if defined(__cplusplus) || defined(__STDC__)
int yyinput(void)
#else
yyinput()
#endif
{
#ifndef __cplusplus
	return(input());
#else
	return(lex_input());
#endif
	}
#if defined(__cplusplus) || defined(__STDC__)
void yyoutput(int c)
#else
yyoutput(c)
  int c; 
#endif
{
#ifndef __cplusplus
	output(c);
#else
	lex_output(c);
#endif
	}
#if defined(__cplusplus) || defined(__STDC__)
void yyunput(int c)
#else
yyunput(c)
   int c; 
#endif
{
	unput(c);
	}
