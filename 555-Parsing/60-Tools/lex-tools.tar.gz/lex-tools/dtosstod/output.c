#include "fortran.h"

#define CONTINUATION_CHARACTER	'X'

int instring = 0;			/* non-zero means inside character */
					/* or Hollerith string, where blanks */
					/* are significant */

static int	last_column = 0;

static void	outblanks ARGS((int n__));
static void	putone ARGS((int c__));


static void
outblanks(n)
int n;
{
    for ( ; n > 0; --n)
	output(' ');
}

void
output(c)		/* private output() routine to handle line wrapping */
int c;
{
    if ((last_column >= 72) && (c != '\n'))
    {					/* wrap to continuation line */
	output('\n');
	outblanks(5);
	output(CONTINUATION_CHARACTER);
    }
    last_column = (c == '\n') ? 0 : (last_column + 1);
    putone(c);	/* ALL output to stdout happens here and only here! */
}

void
outstr(s)				/* output string with line wrapping */
char *s;
{
    int slen = strlen(s);
    int k;
    int nonblanks;

    if ((slen > 1) && ((last_column + slen) > 72) && (slen <= 61))
    {	/* token too long, but would fit on one line, so start new line */
	for (k = 0, nonblanks = 0; s[k]; ++k) /* is token all blank? */
	{
	    if (!isspace(s[k]))
	        nonblanks++;
	}
#if 0
	if ((nonblanks == 0) && (instring == 0))
	{
	    output(' ');		/* preserve possibly-separating */
	    return;			/* single blank at end-of-line */
	}
#endif
	output('\n');
	outblanks(5);
	output(CONTINUATION_CHARACTER);
	/* indent if not character string, and non-blank, and short enough */
	if ((instring == 0) && (nonblanks > 0) &&
	    ((last_column + slen + 5) <= 72))
	    outblanks(5);
    }
    for ( ; *s ; ++s)
	output(*s);
    instring = 0;
}

int lineno = 0;				/* global output line number */

static void
putone(c)				/* all output to stdout comes here */
int c;					/* where it is buffered and blank */
{					/* trimmed */
    static char line[72 + 1 + 1];	/* 72 chars + '\n' + '\0' */
    static int npos = 0;

    if (c == '\n')
	lineno++;

    if (npos > 72)
    {
	(void)fprintf(stderr, "Internal error: buffer overflow at line %d\n",
		      lineno);
	exit (1);
    }
    else
	line[npos++] = c;

    if (c == '\n')
    {
	line[npos] = '\0';		/* add string terminator */
	if (instring == 0)		/* then can blank trim line */
	{
	    for (npos = npos - 2; (npos >= 0) && (line[npos] == ' '); npos--)
	        /* NO-OP */;
	    line[++npos] = c;
	    line[++npos] = '\0';
	}
	if (fputs(line,stdout) == EOF)
	{
            (void)fprintf(stderr, "Output error at line %d\n", lineno);
	    exit (1);
	}
	npos = 0;
    }
}
