#include "fortran.h"

extern int debug;

static char fline[72 + 1 + 1];		/* Fortran line + '\n' + '\0' */
static int nfline = 0;			/* number of chars in fline[] */

static char stmt[MAXSTMT];		/* complete Fortran statement */
static int nstmt = 0;			/* number of characters in stmt[] */


int
inchar()				/* next Fortran statement character */
{					/* handling continuation lines */
    static int kstmt = 0;		/* index of next char in stmt[] */

    if (kstmt >= nstmt)			/* get complete Fortran statement */
    {
        instmt();
	kstmt = 0;
    }
    return ((kstmt < nstmt) ? stmt[kstmt++]: 0);
}


void
infline()				/* read one complete Fortran line,  */
{					/* keeping 72 chars + '\n' */
    int c;

    nfline = 0;
    while (((c = getchar()) != EOF) && (c != '\n'))
    {
	if (nfline < 72)
	    fline[nfline++] = c;
    }
    if (c == EOF)
	fline[nfline++] = '\0';		/* lex end-of-file char */
    else
    {
	for ( ; nfline < 72; )		/* supply padding to column 72 */
	    fline[nfline++] = ' ';
    }
    fline[nfline++] = '\n';
    fline[nfline] = '\0';

#if DEBUG
    if (debug)
    {
	fline[nfline-1] = '\0';
	(void)fprintf(stderr, "infline() -> %d:[%s]\n", nfline, fline);
	fline[nfline-1] = '\n';
    }
#endif

}


void
instmt()				/* get complete Fortran statement */
{
    if (nfline == 0)
	infline();
    (void)strcpy(stmt,fline);
    nstmt = nfline;
    for (;;)
    {
	infline();
	if ((fline[0] == ' ') &&
	    (fline[1] == ' ') &&
	    (fline[2] == ' ') &&
	    (fline[3] == ' ') &&
	    (fline[4] == ' ') &&
	    (fline[5] != ' ') &&
	    (fline[5] != '0') )
	{				/* append continuation line */
	    stmt[--nstmt] = '\0';	/* kill '\n' */
	    (void)strcpy(&stmt[nstmt],&fline[6]);
	    nstmt += nfline - 6;
	    nfline = 0;
	}
	else
	    break;			/* have complete statement */
    }
    for (nstmt -= 2; (nstmt >= 0) && stmt[nstmt] == ' '; nstmt--)
	/* trim trailing space */;
    stmt[++nstmt] = '\n';
    stmt[++nstmt] = '\0';

#if DEBUG
    if (debug)
    {
	stmt[nstmt-1] = '\0';
	(void)fprintf(stderr, "instmt() -> %d:[%s]\n", nstmt, stmt);
	stmt[nstmt-1] = '\n';
    }
#endif

}
