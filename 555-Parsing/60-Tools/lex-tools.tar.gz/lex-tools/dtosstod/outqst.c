#include "fortran.h"

extern int instring;

void
outquotedstring()
{
    instring = 1;
    ECHO;
    instring = 0;
}
