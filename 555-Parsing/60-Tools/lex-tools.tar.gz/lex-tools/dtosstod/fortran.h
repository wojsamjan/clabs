#include <stdio.h>
#include <ctype.h>
#include <string.h>

#if __STDC__
#include <stdlib.h>
#include <stddef.h>
#endif /* __STDC__ */

#define MAXCONT 40			/* Number of continuation lines */
					/* Fortran 77 Standard is 19. */

#define MAXSTMT (72 + MAXCONT*72)	/* pushback buffer size, large */
					/* enough for MAXCONT continuation */
					/* lines */
extern char yytext[];

#if __STDC__
#define ARGS(plist)	plist
#else /* NOT __STDC__ */
#define ARGS(plist)	()
#endif /* __STDC__ */

void	convert_declaration ARGS((void));
void	convert_number ARGS((void));
void	cvtstr ARGS((char *s__));
int	inchar ARGS((void));
void	infline ARGS((void));
int	input ARGS((void));
void	instmt ARGS((void));
void	outhollerith ARGS((void));
void	output ARGS((int c__));
void	outstr ARGS((char *s__));
void	unput ARGS((int c__));

#undef ECHO
#define ECHO	outstr(yytext)
