#include "fortran.h"

extern int lineno;			/* set in output.c */

void
cvtstr(s)			/* output possibly case-converted string */
char *s;
{
    if (*s == '?')			/* no equivalent function available */
    {
	(void)fprintf(stderr,
	   "WARNING: %s has no equivalent in different precision at line %d\n",
	    yytext,lineno + 1);
	outstr(yytext);			/* output original function name */
    }
    else if (islower(yytext[0]))
	outstr(s);
    else
    {
	for ( ; *s ; ++s)
	    output(islower(*s) ? toupper(*s) : *s);
    }
}
