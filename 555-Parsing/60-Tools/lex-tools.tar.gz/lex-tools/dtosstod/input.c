#include "fortran.h"

extern int debug;

static char pushback[MAXSTMT];
static int npushback = 0;		/* number of pushed back characters */

int
input()
{
    int c;

    if (npushback > 0)
	c = pushback[--npushback];
    else
	c = inchar();

#if DEBUG
    if (debug)
	(void)fprintf(stderr,"input() -> [%c]\n",c);
#endif /* DEBUG */

    return (c);
}

void
unput(c)
int c;
{
    pushback[npushback++] = c;

#if DEBUG
    if (debug)
    {
	int k;
	
	(void)fprintf(stderr,
		      "unput(%c) npushback = %d pushback[] = [",
		      c, npushback);
	for (k = npushback - 1; k >= 0; --k)
	{
	    if (isprint(pushback[k]))
		(void)fputc(pushback[k],stderr);
	    else
	        (void)fprintf(stderr,"\\%03o",pushback[k]);
	}
	(void)fprintf(stderr,"]\n");
    }
#endif

}
