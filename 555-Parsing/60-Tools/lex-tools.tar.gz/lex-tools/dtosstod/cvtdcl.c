#include "fortran.h"

extern int dp_output;

void
convert_declaration()
{
    char *p;

    for (p = yytext; *p && isspace(*p); ++p)
	output(*p);
    if (*p == 'i')
	outstr("implicit ");
    else if (*p == 'I')
	outstr("IMPLICIT ");
    if (dp_output)
	outstr(islower(*p) ? "double precision" : "DOUBLE PRECISION");
    else
	outstr(islower(*p) ? "real" : "REAL");
}
