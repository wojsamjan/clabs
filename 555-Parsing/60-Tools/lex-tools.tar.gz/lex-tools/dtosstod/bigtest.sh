#!/bin/sh
# Check the internal consistency of dtos and stod by applying then
# sequentially in a pipeline, and comparing the input with the output.
#
# Any large body of Fortran or SFTRAN3 code in a known precision
# will do.  We use PLOT79 sources here for testing purposes.
#
# Some minor formatting differences are to be expected, but only from
# whitespace, and possibly from elimination of E+00 exponents in
# floating-point constants.
# [11-May-1992]

SPfiles="$PLT/p79core/*.sf3 $PLT/utility/utr*.sf3 $PLT/fnlib/r*.f"
DPfiles="$PLT/utility/utd*.sf3 $PLT/fnlib/d*.f"

echo ==================== Begin dtos to stod test ====================
for f in $DPfiles
do
	echo ========== $f ==========
	./dtos <$f | ./stod | diff -w $f -
done

echo ==================== Begin stod to dtos test ====================
for f in $SPfiles
do
	echo ========== $f ==========
	./stod <$f | ./dtos | diff -w $f -
done
