#include "fortran.h"

extern int instring;

void
outhollerith()
{
    int n;
    char *p;

    for (p = (char*)yytext, n = 0; *p; ++p)
    {
	if (isdigit(*p))
	    n = 10*n + (int)(*p - '0');
    }
    for ( ; n > 0; --n)			/* collect n Hollerith characters */
	*p++ = input();			/* after nnnH in yytext[] */
    *p = '\0';
    instring = 1;
    ECHO;
    instring = 0;
}
