#!/bin/sh
# Check the internal consistency of dtoq and qtod by applying then
# sequentially in a pipeline, and comparing the input with the output.
#
# Any large body of Fortran or SFTRAN3 code in a known precision
# will do.  We use PLOT79 sources here for testing purposes.
#
# Some minor formatting differences are to be expected, but only from
# whitespace, and possibly from elimination of E+00 exponents in
# floating-point constants.
# [27-Apr-1993]

DPfiles="$PLT/utility/utd*.sf3 $PLT/fnlib/d*.f"
# We need to generate some quadruple-precision files for testing
QPfiles=

echo ==================== Begin dtoq to qtod test ====================
for f in $DPfiles
do
	echo ========== $f ==========
	./dtoq <$f | ./qtod | diff -w $f -
done

echo ==================== Begin qtod to dtoq test ====================
for f in $QPfiles
do
	echo ========== $f ==========
	./qtod <$f | ./dtoq | diff -w $f -
done
