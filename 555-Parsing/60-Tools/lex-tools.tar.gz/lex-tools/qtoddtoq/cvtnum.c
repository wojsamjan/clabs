#include "fortran.h"

extern int qp_output;
extern int instring;

void
convert_number()
{
    char *p;
    char *p_exponent = (char*)NULL;
    int exponent_seen = 0;
    int exponent_value = 0;

    for (p = yytext; *p; ++p)
    {
	switch (*p)
	{
	case 'Q':
	case 'q':
	    if (!qp_output)
		*p += 'd' - 'q';
	    p_exponent = p;
	    exponent_seen++;
	    break;

	case 'D':
	case 'd':
	    if (qp_output)
		*p += 'q' - 'd';
	    p_exponent = p;
	    exponent_seen++;
	    break;

	case '0':
	case '1':
	case '2':
	case '3':
	case '4':
	case '5':
	case '6':
	case '7':
	case '8':
	case '9':
	    if (exponent_seen)
	        exponent_value = 10*exponent_value + (int)(*p - '0');
	    break;

	default:
	    break;
	}
    }
    instring = 1;			/* no line breaks in numbers */
    ECHO;
    instring = 0;
}
