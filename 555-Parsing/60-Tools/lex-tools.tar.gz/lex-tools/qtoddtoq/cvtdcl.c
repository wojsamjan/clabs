#include "fortran.h"

extern int qp_output;

void
convert_declaration()
{
    char *p;

    for (p = yytext; *p && isspace(*p); ++p)
	output(*p);
    if (*p == 'i')
	outstr("implicit ");
    else if (*p == 'I')
	outstr("IMPLICIT ");
    if (qp_output)
	outstr(islower(*p) ? "real*16" : "REAL*16");
    else
	outstr(islower(*p) ? "double precision" : "DOUBLE PRECISION");
}
