#include "xmalloc.h"
#include "stdlib.h"

void *xmalloc(int size)
{
  void *ptr;
  ptr = malloc(size);
  if(ptr == NULL){
    printf("Out of memory\n");
    exit(1);
  }
  return ptr;
}

void *xrealloc(void *oldptr, int size)
{
  void *ptr;
  if(oldptr == NULL)
    ptr = malloc(size);
  else
    ptr = realloc(oldptr, size);
  if(ptr == NULL){
    printf("Out of memory\n");
    exit(1);
  }
  return ptr;
}
  
