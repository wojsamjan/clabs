#include <stdio.h>

int main(int argc, char *argv[])
{
  FILE *in, *out;
  int c;

  if(argc!=3){
    printf("Podaj argumenty!\n");
    exit(1);
  }
  if((in=fopen(argv[1], "rt"))==NULL){
    printf("Nie mog�em otworzy� %s\n", argv[1]);
    exit(1);
  }
  if((out=fopen(argv[2], "wt"))==NULL){
    printf("Nie mog�em otworzy� %s\n", argv[2]);
    exit(1);
  }
  while((c=fgetc(in))!=EOF)
    fprintf(out,"%d",c % 2);

  fclose(in);
  fclose(out);
  return 0;
}
