#define FLST1 "\t\tint num_chars=0;\n\
%%%%\n"

#define FLST2 "{ printf(\"Ci�g %%s na pozycji %%d\\n\", yytext, num_chars);\n\
                  num_chars = num_chars+yyleng; }\n\
. |\n\
\\n             num_chars++;\n\
\n\
%%%%\n\
int\n\
main()\n\
{\n\
  yylex();\n\
  return 0;\n\
}\n\
\n\
int\n\
yywrap()\n\
{\n\
  return 1;\n\
}\n"

#define BSST1 "%%{\n\
#include <stdio.h>\n\
#define YYSTYPE char *\n\
int tkcount=0;\n
char *acat(char *s);\n\
char *bcat(char *s1, char *s2);\n
%%}\n\
%%%%\n\
line: start\n\
  | error\n\
  | line start\n\
  | line error { tkcount++; }\n\
  ;\n\
start: re0 { printf(\"Ci�g %%s na pozycji ok. %%d\\n\", $1, tkcount); tkcount+=strlen($1);};\n"

#define BSST2 "%%%%\n\
char *acat(char *s)\n\
{\n\
   char *temp;\n\
   temp = (char *)malloc(strlen(s)+1);\n\
   strcpy(temp,s);\n\
   return temp;\n\
}\n\
char *bcat(char *s1, char *s2)\n\
{\n\
   char *temp;\n\
   temp = (char *)malloc(strlen(s1)+strlen(s2)+1);\n\
   strcpy(temp,s1);\n\
   strcat(temp,s2);\n\
   return temp;\n\
}\n\
\n\
int yylex()\n\
{\n\
  int c;\n\
  c=getchar();\n\
  if (c==EOF) return(0);\n\
  return(c);\n\
}\n\
int yyerror(char *s)\n\
{\n\
}\n\
int main()\n\
{\n\
  yyparse();\n\
}\n"

typedef struct retree {
   int type; /* 0 - lisc, 1 - binop, 2 - unop */
   int op;   /* 0 "+", 1 ".", 2 "*" */
   unsigned char val;
   struct retree *l;
   struct retree *r;
} RETREE, *PRETREE;

void do_example1(PRETREE pre, char *fname);
void do_example2(PRETREE pre, char *fname);
void do_example3(PRETREE pre, char *fname);
void do_examples(PRETREE pre);

PRETREE b_leaf(unsigned char c);

PRETREE b_bin(PRETREE l, PRETREE r, int op);

PRETREE b_un(PRETREE l, int op);
