#!/bin/bash
cat $1 | ./ex2 > /dev/null