#!/bin/bash
cat $1 | ./ex1 > /dev/null