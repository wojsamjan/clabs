void *xmalloc(int size);

void *xrealloc(void *oldptr, int size);
  
