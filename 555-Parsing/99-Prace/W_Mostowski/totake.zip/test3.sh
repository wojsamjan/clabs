#!/bin/bash
cat $1 | ./ex3 > /dev/null