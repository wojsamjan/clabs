#include <stdlib.h>
#include <stdio.h>
#include "xmalloc.h"
#include "automaton.h"

#define ST1 "#include <stdio.h>\n\
#include <stdlib.h>\n\
#define BUFSIZE 65535\n\
\n\
int a[][256] = \n"

#define ST2 ";\n\
\n\
unsigned char all[BUFSIZE+1];\n\
\n\
int is_accept(int state)\n\
{\n\
  switch(state){\n"

#define ST3 "      return 1;\n\
  }\n\
  return 0;\n\
}\n\
\n\
int check_re(unsigned char *string)\n\
{\n\
   unsigned char *ptr;\n\
   int len=0;\n\
   int i=-1;\n\
   int state = 0;\n\
   ptr = string;\n\
   while(*ptr != 0){\n\
     if(a[state][*ptr] == -1)\n\
       return i;\n\
     state = a[state][*ptr];\n\
     ptr++;\n\
     len++;\n\
     if(is_accept(state))\n\
       i = len;\n\
   }\n\
   return i;\n\
}\n\n\
int main()\n\
{\n\
  int len=0, i, c;\n\
  unsigned char temp[BUFSIZE];\n\
  while((c=getchar())!=EOF){\n\
    all[len++]=c;\n\
    if(len == BUFSIZE) break;\n\
  }\n\
  all[len]=0;\n\
  for(i=0;i<len;i++){\n\
    c = check_re(all+i);\n\
    if(c >= 0){\n\
       strncpy(temp,all+i,c);\n\
       temp[c]=0;\n\
       printf(\"Ci�g %%s na pozycji %%d\\n\", temp, i);\n\
       i = i + c - 1;\n\
    }\n\
  }\n\
  return 0;\n\
}\n"

PINTLIST addtolist(int value, PINTLIST list)
{
  PINTLIST ptr;

  if(isinlist(list,value))
    ptr = list;
  else{
    ptr = xmalloc(sizeof(INTLIST));
    ptr->value=value;
    ptr->next=list;
  };
  return ptr;
}

int isinlist(PINTLIST list, int value)
{
  if(list==NULL)
    return 0;
  if(list->value==value)
    return 1;
  return(isinlist(list->next, value));
}

PINTLIST addtoeachinlist(PINTLIST list, int value)
{
  PINTLIST ptr, ptr2;
  ptr = list;
  ptr2 = NULL;
  while(ptr != NULL){
    ptr2=addtolist(ptr->value + value, ptr2);
    ptr = ptr->next;
  }
  return(ptr2);
}

PINTLIST clonelist(PINTLIST list)
{
  PINTLIST ptr, ptr2;
  ptr = list;
  ptr2 = NULL;
  while(ptr != NULL){
    ptr2=addtolist(ptr->value, ptr2);
    ptr = ptr->next;
  }
  return(ptr2);
}

PINTLIST unionlist(PINTLIST l1, PINTLIST l2)
{
  PINTLIST ptr, ptr2;
  ptr = clonelist(l1);
  ptr2 = l2;
  while(ptr2 != NULL){
    //    if(!isinlist(ptr,ptr2->value))
      ptr = addtolist(ptr2->value, ptr);
    ptr2 = ptr2->next;
  }
  return(ptr);
}

PINTLIST removelist(PINTLIST list, int value)
{
  PINTLIST ptr, ptr2;
  ptr = list;
  ptr2 = NULL;
  while(ptr != NULL){
    if(ptr->value != value)
      ptr2=addtolist(ptr->value, ptr2);
    ptr = ptr->next;
  }
  return(ptr2);  
}

int listsize(PINTLIST list)
{
  if(list==NULL)
    return 0;
  return(listsize(list->next)+1);
}

PAUTOMATON create_atom(int letter, int alphabet)
{
  PAUTOMATON a;
  PINTLIST p, *p1, *p2, **p3;
  int i;
  a = xmalloc(sizeof(AUTOMATON));
  if(letter > alphabet){
    printf("B��d\n");
    exit(1);
  };
  a->alphabet=alphabet;
  a->vsize=2;
  p = addtolist(1, NULL);
  p1 = xmalloc(a->alphabet*sizeof(PINTLIST));
  p2 = xmalloc(a->alphabet*sizeof(PINTLIST));
  p3 = xmalloc(a->vsize*sizeof(PINTLIST *));
  for(i=0;i<alphabet;i++){
    p1[i]=NULL;
    p2[i]=NULL;
  };
  p1[letter] = p;
  p3[0]=p1;
  p3[1]=p2;
  a->trans=p3;
  a->fstates=addtolist(1,NULL);
  return a;
}

PAUTOMATON create_cat(PAUTOMATON a1, PAUTOMATON a2)
{
  PAUTOMATON a;
  PINTLIST *fl, nfstates;
  PINTLIST *p1, **p3;
  int i, j;

  if(a1 == NULL || a2 == NULL){
    printf("B��d\n");
    exit(1);
  };

  a = xmalloc(sizeof(AUTOMATON));

  if(a1->alphabet!=a2->alphabet){
    printf("B��d\n");
    exit(1);
  };
  a->alphabet=a1->alphabet;
  a->vsize=a1->vsize+a2->vsize-1;

  fl = xmalloc(a->alphabet*sizeof(PINTLIST));
  for(i=0;i<a->alphabet;i++) 
    fl[i]=addtoeachinlist(a2->trans[0][i], a1->vsize-1);

  p3 = xmalloc(a->vsize*sizeof(PINTLIST *));
  for(i=0;i<a1->vsize;i++){
    p1 = xmalloc(a->alphabet*sizeof(PINTLIST));
    for(j=0;j<a->alphabet;j++){
      p1[j] = clonelist(a1->trans[i][j]);
      if(isinlist(a1->fstates, i))
        p1[j] = unionlist(p1[j], fl[j]);
    };
    p3[i] = p1;
  };

  for(i=1;i<a2->vsize;i++){
    p1 = xmalloc(a->alphabet*sizeof(PINTLIST));
    for(j=0;j<a->alphabet;j++){
      p1[j] = clonelist(a2->trans[i][j]);
      p1[j] = addtoeachinlist(p1[j], a1->vsize-1);
    };
    p3[a1->vsize+i-1] = p1;
  };
  a->trans=p3;

  nfstates = addtoeachinlist(a2->fstates, a1->vsize-1);
  if(isinlist(a2->fstates,0))
    a->fstates = unionlist(a1->fstates, nfstates);
  else
    a->fstates = nfstates;
  return a;
}

PAUTOMATON create_sum(PAUTOMATON a1, PAUTOMATON a2)
{
  PAUTOMATON a;
  PINTLIST *fl, nfstates, anfstates;
  PINTLIST *p1, **p3;
  int i, j;

  if(a1 == NULL || a2 == NULL){
    printf("B��d\n");
    exit(1);
  };

  a = xmalloc(sizeof(AUTOMATON));

  if(a1->alphabet!=a2->alphabet){
    printf("B��d\n");
    exit(1);
  };
  a->alphabet=a1->alphabet;


  a->vsize=a1->vsize+a2->vsize-1;

  fl = xmalloc(a->alphabet*sizeof(PINTLIST));
  for(i=0;i<a->alphabet;i++) 
    fl[i]=addtoeachinlist(a2->trans[0][i], a1->vsize-1);

  p3 = xmalloc(a->vsize*sizeof(PINTLIST *));

  p1 = xmalloc(a->alphabet*sizeof(PINTLIST));
  for(i=0;i<a->alphabet;i++) 
    p1[i]=unionlist(a1->trans[0][i], fl[i]);

  p3[0] = p1;

  for(i=1;i<a1->vsize;i++){
    p1 = xmalloc(a->alphabet*sizeof(PINTLIST));
    for(j=0;j<a->alphabet;j++)
      p1[j] = clonelist(a1->trans[i][j]);
    p3[i] = p1;
  };

  for(i=1;i<a2->vsize;i++){
    p1 = xmalloc(a->alphabet*sizeof(PINTLIST));
    for(j=0;j<a->alphabet;j++){
      p1[j] = clonelist(a2->trans[i][j]);
      p1[j] = addtoeachinlist(p1[j], a1->vsize-1);
    };
    p3[a1->vsize+i-1] = p1;
  };
  a->trans=p3;

  anfstates = clonelist(a2->fstates);
  nfstates = clonelist(a1->fstates);
  if(isinlist(anfstates,0)){
    anfstates = removelist(anfstates,0);
    nfstates = addtolist(0,nfstates);
  }
  anfstates = addtoeachinlist(anfstates, a1->vsize-1);
  a->fstates = unionlist(nfstates,anfstates);
  return a;
}

PAUTOMATON create_star(PAUTOMATON a1)
{
  PAUTOMATON a;
  PINTLIST *fl, nfstates;
  PINTLIST *p1, **p3;
  int i, j;

  if(a1 == NULL){
    printf("B��d\n");
    exit(1);
  };

  a = xmalloc(sizeof(AUTOMATON));

  a->alphabet=a1->alphabet;

  a->vsize=a1->vsize;

  fl = xmalloc(a->alphabet*sizeof(PINTLIST));
  for(i=0;i<a->alphabet;i++) 
    fl[i]=clonelist(a1->trans[0][i]);

  p3 = xmalloc(a->vsize*sizeof(PINTLIST *));

  for(i=0;i<a1->vsize;i++){
    p1 = xmalloc(a->alphabet*sizeof(PINTLIST));
    for(j=0;j<a->alphabet;j++){
      p1[j] = clonelist(a1->trans[i][j]);
      if(isinlist(a1->fstates,i))
        p1[j] = unionlist(p1[j], fl[j]);
    };
    p3[i] = p1;
  };
  a->trans=p3;
  nfstates = clonelist(a1->fstates);
  a->fstates = addtolist(0,nfstates);
  return a;
}

int comparelist(PINTLIST l1, PINTLIST l2)
{
  PINTLIST ptr;
  if(listsize(l1) != listsize(l2))
    return 0;
  ptr = l1;
  while(ptr != NULL){
    if(!isinlist(l2,ptr->value))
      return 0;
    ptr = ptr->next;
  }
  ptr = l2;
  while(ptr != NULL){
    if(!isinlist(l1,ptr->value))
      return 0;
    ptr = ptr->next;
  }
  return 1;
}

int indexof(PINTLIST *states, int stsize, PINTLIST nis)
{
  int i;
  for(i=0;i<stsize;i++)
    if(comparelist(states[i], nis))
      return i;
  return -1;
}

PAUTOMATON create_deterministic(PAUTOMATON a1)
{
  PAUTOMATON a;
  PINTLIST *states, nis, nfstates;
  PINTLIST *p1, **p3, ptr;
  int i, j, l, stsize;
  if(a1 == NULL){
    printf("B��d\n");
    exit(1);
  };
  a = xmalloc(sizeof(AUTOMATON));
  a->alphabet=a1->alphabet;
  a->vsize=0;
  p3=NULL;
  nfstates=NULL;

  stsize = 1;
  states = xmalloc(stsize*sizeof(PINTLIST));

  states[0] = addtolist(0,NULL);
  i=0;
  while(i<stsize){
    p1 = xmalloc(a->alphabet*sizeof(PINTLIST));
    for(l=0; l<a->alphabet;l++){
      ptr = states[i];
      nis = NULL;
      while(ptr !=NULL){
	nis = unionlist(a1->trans[ptr->value][l],nis); 
        ptr = ptr->next;
      }
      p1[l] = NULL;
      if(listsize(nis) != 0){
        if(indexof(states, stsize, nis)==-1){
	  stsize++;
          states=xrealloc(states, stsize*sizeof(PINTLIST));
          states[stsize-1]=nis;
	};
	j = indexof(states, stsize, nis);
        p1[l]=addtolist(j,p1[l]);
      }
    }
    a->vsize=a->vsize+1;
    p3 = xrealloc(p3,a->vsize*sizeof(PINTLIST *));
    p3[a->vsize-1]=p1;
    i++;
  };
  a->trans=p3;
  for(j=0;j<stsize;j++){
    ptr=a1->fstates;
    while(ptr != NULL){
      if(isinlist(states[j], ptr->value))
        nfstates=addtolist(j,nfstates);
      ptr=ptr->next;
    }
  }
  a->fstates = nfstates;
  return a;
}

void printa1(FILE *out, PAUTOMATON a){
  int i, j;
  fprintf(out, "{");
  for(i=0;i<a->vsize;i++){
    fprintf(out, "{");
    for(j=0;j<a->alphabet;j++){
      if(a->trans[i][j]==NULL)
        fprintf(out, "-1");
      else
        fprintf(out, "%d", a->trans[i][j]->value);
      if(j!=a->alphabet-1)
        fprintf(out, ",");
    }
    fprintf(out, "}");
    if(i!=a->vsize-1)
      fprintf(out, ",\n");  
  }
  fprintf(out, "}\n");
}

void printa2(FILE *out, PAUTOMATON a)
{
  PINTLIST ptr;
  ptr = a->fstates;
  while(ptr != NULL){
    fprintf(out, "    case %d:\n", ptr->value);
    ptr = ptr->next;
  }

}

void print_file(FILE *out, PAUTOMATON a)
{
  fprintf(out,ST1);
  printa1(out,a);
  fprintf(out,ST2);
  printa2(out,a);
  fprintf(out,ST3);
}
