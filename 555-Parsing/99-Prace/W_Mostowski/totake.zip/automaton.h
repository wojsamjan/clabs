typedef struct intlist {
  int value;
  struct intlist *next;
} INTLIST, *PINTLIST;

typedef struct automaton {
  int alphabet;
  int vsize;
  PINTLIST fstates;
  PINTLIST **trans;
} AUTOMATON, *PAUTOMATON;

PAUTOMATON create_atom(int letter, int alphabet);
PAUTOMATON create_cat(PAUTOMATON a1, PAUTOMATON a2);
PAUTOMATON create_sum(PAUTOMATON a1, PAUTOMATON a2);
PAUTOMATON create_star(PAUTOMATON a1);
PAUTOMATON create_deterministic(PAUTOMATON a1);
void print_file(FILE *out, PAUTOMATON a);
