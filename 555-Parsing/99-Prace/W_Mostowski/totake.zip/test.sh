#!/bin/bash
echo "Przygotowanie:"
cat $1 | ./do_examples
make examples
echo
echo
echo "Wyszukiwanie przez automat:"
echo
time ./test1.sh $2
echo
echo
echo "Wyszukiwanie przez flex:"
echo
time ./test2.sh $2
echo
echo
echo "Wyszukiwanie przez bison:"
echo
time ./test3.sh $2
echo
echo