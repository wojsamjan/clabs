/***************************************************************************

  Operacje plikowe - zapis i odczyt bazy danych z pliku
  deklaracje

****************************************************************************/

#ifndef _FILEIO_H
#define _FILEIO_H

/* zapis bazy danych w pliku */
int file_write_data(char *fname);

/* odczyt bazy danych z pliku */
int file_read_data(const char *fname);

#endif