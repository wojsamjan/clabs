/***************************************************************************

  Interfejs u�ytkownika - rozpoznawanie i wykonywanie polece�
  implementacja

****************************************************************************/

#include <string.h>
#include <stdio.h>
#include <memory.h>
#include "command.h"
#include "hashtbl.h"
#include "data.h"
#include "misc.h"
#include "fileio.h"

/* typ wska�nika do funkcji komendy */
typedef void (*COMMAND_HANDLER)(char *params);

/* struktura przechowuj�ca list� znanych komend */
typedef struct tCOMMAND
{
   char *cmd;
   COMMAND_HANDLER handler;
} COMMAND;

int cmnd_check_param(int cond, char *msg)
{
   if(cond)
      printf("\n%s\n", msg);
   return cond;
}

/* wewn�trzne deklaracje nag��wk�w funkcji wykonawczych */
void cmd_add(char *params);
void cmd_delete(char *params);
void cmd_find(char *params);
void cmd_update(char *params);
void cmd_dump(char *params);
void cmd_load(char *params);
void cmd_save(char *params);
void cmd_clear(char *params);
void cmd_exit(char *params);
void cmd_help(char *params);

/* tablica znanych rozkaz�w i ich procedur obs�ugi */
COMMAND commands[] =
{
   {"add", cmd_add},
   {"delete", cmd_delete},
   {"find", cmd_find},
   {"update", cmd_update},
   {"dump", cmd_dump},
   {"load", cmd_load},
   {"save", cmd_save},
   {"?", cmd_help},
   {"clear", cmd_clear},
   {"exit", cmd_exit}
};

char *strBadParam =
  "Nieprawid�owy parametr. Wprowad� '?' <enter> aby uzyska� pomoc.";
char *strHelp =
  "\nDost�pne komendy:"
  "\n   add <data>         - dodanie danych do bazy"
  "\n                        gdzie <data> = klucz;autor;tytu�;rok_wydania"
  "\n   delete <key>       - usuni�cie danych wg podanego klucza"
  "\n   find <key>         - odnalezienie i wy�wietlenie danych wg klucza"
  "\n   update <data>      - zast�pienie danych nowymi danymi"
  "\n   dump               - wy�wietlenie zawarto�ci bazy danych"
  "\n   load <filename>    - odczyt bazy danych z pliku"
  "\n   save <filename>    - zapis bazy danych do pliku"
  "\n   clear              - usuni�cie danych z bazy"
  "\n   exit               - wyjscie"
  "\n\nnp."
  "\n   add poz1;Mark Twain;Przygody Tomka Sawyera;1999"
  "\n   add poz2;Julian Tuwim;Lokomotywa;1986"
  "\n   dump"
  "\n   save test.dat"
  "\n   clear"
  "\n   dump"
  "\n   load test.dat"
  "\n   dump"
  "\n";

/* -------------------------------------------------------------------------
   rozpoznaje i wykonuje podan� komend�
*/
int cmnd_recognize_and_execute(char *func, char *cmd_line)
{
   int i, rslt = 1;
   for(i=0; i < sizeof(commands) / sizeof(COMMAND); i++)
   {
      if(!stricmp(commands[i].cmd, func))
      {
         commands[i].handler(cmd_line);
         break;
      };
   };
   cmnd_check_param(i == sizeof(commands) / sizeof(COMMAND),
      "Nieznana komenda. Wprowad� '?' <enter> aby uzyska� pomoc.");
   return rslt;
}

/* wykonanie komendy add */
void cmd_add(char *params)
{
   BOOK data, *ptr;
   if(cmnd_check_param(*params=='\0', strBadParam))
      return;

   data_delimited_to_data(&data, params);

   if(cmnd_check_param(*data.key=='\0', "Nie podano klucza"))
      return;

   ptr = htbl_insert_key(data.key, sizeof(BOOK));
   if(ptr)
      memcpy(ptr, &data, sizeof(BOOK));
}

/* wykonanie komendy delete */
void cmd_delete(char *params)
{
   BOOK data;

   if(cmnd_check_param(*params=='\0', strBadParam))
      return;

   data_delimited_to_data(&data, params);

   if(cmnd_check_param(*data.key=='\0', "Nie podano klucza"))
      return;

   htbl_remove_key(data.key);
}

/* wykonanie komendy find */
void cmd_find(char *params)
{
   BOOK *ptr, data;

   if(cmnd_check_param(*params=='\0', strBadParam))
      return;

   data_delimited_to_data(&data, params);

   if(cmnd_check_param(*data.key=='\0', "Nie podano klucza"))
      return;

   if(cmnd_check_param(NULL==(ptr=(BOOK *)htbl_find_key(data.key)), "Nie odnaleziono klucza."))
      return;

   data_print(ptr);
}

/* wykonanie komendy update */
void cmd_update(char *params)
{
   BOOK *ptr, data;

   if(cmnd_check_param(*params=='\0', strBadParam))
      return;

   data_delimited_to_data(&data, params);

   if(cmnd_check_param(*data.key=='\0', "Nie podano klucza"))
      return;

   if(cmnd_check_param(NULL==(ptr=(BOOK *)htbl_find_key(data.key)), "Nie odnaleziono klucza."))
      return;

   htbl_remove_key(data.key);
   ptr = htbl_insert_key(data.key, sizeof(BOOK));
   if(ptr)
      memcpy(ptr, &data, sizeof(BOOK));
}

/* wykonanie komendy dump */
void cmd_dump_callback(void *item, DWORD hash_value)
{
   printf("\n0x%08x  ", hash_value);
   data_print((BOOK *)item);
}

void cmd_dump(char *params)
{
   printf("\nhash #      ");
   data_print_table_header();
   printf("\n----------  ");
   data_print_table_separator();

   htbl_for_each(cmd_dump_callback);
   printf("\n");
}

/* wykonanie komendy load */
void cmd_load(char *params)
{
   cmd_clear(NULL);
   file_read_data(params);
}

/* wykonanie komendy save */
void cmd_save(char *params)
{
   file_write_data(params);
}

/* wykonanie komendy clear */
void cmd_clear(char *params)
{
   htbl_finalize();
   htbl_initialize();
}

/* wykonanie komendy exit */
void cmd_exit(char *params)
{
}

/* wykonanie komendy help */
void cmd_help(char *params)
{
   printf(strHelp);
}

