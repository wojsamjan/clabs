#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "data.h"

/* drukuje sformatowan� zawarto�� struktury danych */
void data_print(BOOK *data)
{
	printf("%-*s %-*s %-*s   %4i",
		DT_KEY_SIZE,    data->key,
		DT_AUTHOR_SIZE, data->author,
		DT_TITLE_SIZE,  data->title,
		data->year_of_issue);
}

/* drukuje sformatowany nag��wek informacyjny struktury danych */
void data_print_table_header(void)
{
	printf("%-*s %-*s %-*s wydana",
		DT_KEY_SIZE,    "Klucz",
		DT_AUTHOR_SIZE, "Autor",
		DT_TITLE_SIZE,  "Tytu�");
}

/* drukuje separator tabeli */
void data_print_table_separator(void)
{
	int i = DT_KEY_SIZE + DT_AUTHOR_SIZE + DT_TITLE_SIZE + 9;
	while(i--)
		putchar('-');
}

/* -------------------------------------------------------------------------
   zamienia ci�g znak�w zawieraj�cych pola klucz, autor, tytu�, rok_wydania
   oddzielone �rednikiem ";" na pola struktury
*/
void data_delimited_to_data(BOOK *data, char *delimited)
{
   char *ptr = strtok(delimited, ";");
   memset(data, 0, sizeof(BOOK));   
   if(!ptr)
      return;
   strncpy(data->key, ptr, DT_KEY_SIZE);
   ptr = strtok(NULL, ";");
   if(!ptr)
      return;
   strncpy(data->author, ptr, DT_AUTHOR_SIZE);
   ptr = strtok(NULL, ";");
   if(!ptr)
      return;
   strncpy(data->title, ptr, DT_TITLE_SIZE);
   ptr = strtok(NULL, ";");
   if(!ptr)
      return;
   data->year_of_issue = atoi(ptr);
}

