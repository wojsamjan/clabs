#include <stdio.h>
#include <stdlib.h>
#include "misc.h"

void err_terminate(const char *msg)
{
   printf("\n%s\n", msg);
   exit(EXIT_FAILURE);
}



