/***************************************************************************

  Funkcje zwi�zane z obs�ug� hashowania.

***************************************************************************/
  
#ifndef __hashtblH_h
#define __hashtblH_h

#include <malloc.h>
#include "misc.h"

#define  HASH_TABLE_SIZE   0x03FFF		/* liczba element�w tablicy hash */
#define  HASH_INITVAL	   0x32abe712	/* warto�� obrana arbitralnie, u�ywana przy hashowaniu */

/* typ u�ywany jako funkcja wywo�ania zwrotnego (callback) przy
   iterowaniu tablicy hash */
typedef void (*HASHTBL_CALLBACK_FUNC)(void *data, DWORD hash_value);

/* inicjacja tablicy hash */
void htbl_initialize(void);

/* zwolnienie tablicy hash */
void htbl_finalize(void);

/* Wstawienie klucza */
void * htbl_insert_key(const char *key, size_t data_size);

/* Usuni�cie klucza */
int htbl_remove_key(const char *key);

/* odnalezienie klucza */
const void * htbl_find_key(const char *key);

/* iteracja po wszystkich zaj�tych elementach tablicy hash */
void htbl_for_each(HASHTBL_CALLBACK_FUNC user_func);

#endif
