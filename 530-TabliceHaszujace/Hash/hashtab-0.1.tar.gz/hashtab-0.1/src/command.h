/***************************************************************************

  Interfejs u�ytkownika - rozpoznawanie i wykonywanie polece�
  deklaracje

****************************************************************************/

#ifndef _command_H
#define _command_H

/* rozpoznanie i wykonanie komendy */
int cmnd_recognize_and_execute(char *func, char *cmd_line);

#endif
