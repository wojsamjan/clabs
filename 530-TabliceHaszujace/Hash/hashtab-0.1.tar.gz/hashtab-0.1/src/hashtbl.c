/***************************************************************************

  Funkcje zwi�zane z obs�ug� hashowania.

  Metoda sk�adowania danych jest nast�puj�ca: podany unikalny klucz
  zamieniany jest na warto�� typu DWORD (zdef. w misc.h) z zakresu
  0x0000-HASH_TABLE_SIZE.
  Otrzymana warto�� jest indeksem tablicy wska�nik�w wskazuj�cych na zaalo-
  kowane bloki pami�ci przechowuj�ce dane. Element tablicy == NULL oznacza
  element nie u�ywany.

  Ze wzgl�du na prosty algorytm hashowania klucza mog� wyst�powa� konflikty
  kluczy (tzn. mo�liwe �e znajd� si� dwa lub wi�cej r�nych kluczy, kt�rych
  hashowanie da w wyniku t� sam� liczb�. Mo�na to rozwi�za� stosuj�c dodatkowo
  metody rozwi�zywania konflikt�w wed�ug jednego z algorytm�w: ***, kt�rych tu
  nie zaimplementowano)

*****************************************************************************/

#include <memory.h>
#include <stdio.h>
#include <string.h>
#include "hashtbl.h"
#include "misc.h"

void **hash_table = NULL;

/* ------------------------------------------------------------------
   funkcja hashuj�ca. Zamienia podany ci�g znak�w na liczb� ca�kowit� 
   typu DWORD (32-bit int), kt�ra b�dzie wykorzystana jako indeks elementu
   w tablicy hash

   Autorem poni�szego algorytmu hashowania jest Bob Jenkins
      bob_jenkins@burtleburtle.net
      http://burtleburtle.net/bob/hash/evahash.html
*/

#define mix(a,b,c) \
{ \
  a -= b; a -= c; a ^= (c>>13); \
  b -= c; b -= a; b ^= (a<<8); \
  c -= a; c -= b; c ^= (b>>13); \
  a -= b; a -= c; a ^= (c>>12);  \
  b -= c; b -= a; b ^= (a<<16); \
  c -= a; c -= b; c ^= (b>>5); \
  a -= b; a -= c; a ^= (c>>3);  \
  b -= c; b -= a; b ^= (a<<10); \
  c -= a; c -= b; c ^= (b>>15); \
}

DWORD htbl_hash(char *k, int length, DWORD initval)
{
   DWORD a,b,c,len;

   len = length;
   a = b = 0x9e3779b9;  
   c = initval;         

   while (len >= 12)
   {
      a += (k[0] +((DWORD)k[1]<<8) +((DWORD)k[2]<<16) +((DWORD)k[3]<<24));
      b += (k[4] +((DWORD)k[5]<<8) +((DWORD)k[6]<<16) +((DWORD)k[7]<<24));
      c += (k[8] +((DWORD)k[9]<<8) +((DWORD)k[10]<<16)+((DWORD)k[11]<<24));
      mix(a,b,c);
      k += 12; len -= 12;
   }

   c += length;
   switch(len)              
   {
		case 11: c+=((DWORD)k[10]<<24);
		case 10: c+=((DWORD)k[9]<<16);
		case 9 : c+=((DWORD)k[8]<<8);    
		case 8 : b+=((DWORD)k[7]<<24);
		case 7 : b+=((DWORD)k[6]<<16);
		case 6 : b+=((DWORD)k[5]<<8);
		case 5 : b+=k[4];
		case 4 : a+=((DWORD)k[3]<<24);
		case 3 : a+=((DWORD)k[2]<<16);
		case 2 : a+=((DWORD)k[1]<<8);
		case 1 : a+=k[0];
   }
   mix(a,b,c);

   return c;
}

DWORD htbl_calc_hash(const char *key)
{
	/* przyci�cie wyniku hashowania do rozmiaru tablicy - warto�� b�dzie
	   u�ywana jako indeks */
	return htbl_hash((char *)key, (int)strlen(key), HASH_INITVAL) % HASH_TABLE_SIZE;
}

/* ------------------------------------------------------------------
   Inicjacja tablicy w kt�rej przechowywane s� wska�niki do danych
*/
void htbl_initialize(void)
{
   hash_table = malloc(sizeof(void*) * HASH_TABLE_SIZE);
   if(!hash_table)
      err_terminate("\nNie uda�o si� zaalokowa� pami�ci na tablic� hash.");
   memset(hash_table, 0, sizeof(void*) * HASH_TABLE_SIZE);
}

/* ------------------------------------------------------------------
   Zwolnienie tablicy i pami�tanych danych.
*/
void htbl_delete_item_callback(void *item, DWORD hash_value)
{
   free(item);
   hash_table[hash_value] = NULL;
}

void htbl_finalize(void)
{
   if(hash_table==NULL)
      return;
   htbl_for_each(htbl_delete_item_callback);    // zwolnienie danych
   free(hash_table);                            // i samej tablicy
}

/* ------------------------------------------------------------------
   Wstawienie klucza

   Funkcja dokonuje wstawienia klucza do tablicy hash. Je�eli mo�liwe jest
   wstawienie podanego klucza, dokonywana jest alokacja pami�ci o rozmiarze
   okre�lonym przez parametr <size> (w celu skopiowania tam danych skojarzo-
   nych z kluczem).
   Zwraca wska�nik do zaalokowanej pami�ci na dane lub NULL, je�eli wstawienie
   podanego klucza jest niemo�liwe (brak pami�ci lub klucz istnieje)
*/
void * htbl_insert_key(const char *key, size_t data_size)
{
	DWORD idx = htbl_calc_hash(key);
	if(hash_table[idx])
	{
		/* tu powinno by� sprawdzenie, czy klucz wcze�niej wprowadzony to ten
		   sam klucz i ewentualne obs�u�enie konfliktu. Poniewa� niniejsza imple-
		   mentacja nie obs�uguje rozwi�zywania konflikt�w, w przypadku napotkania
         zaj�tej kom�rki zak�adamy �e klucz ju� istnieje.
	    */
		printf("\nKom�rka tablicy hashuj�cej jest ju� zaj�ta (klucz istnieje)\n");
		return NULL;
	};
	/* kom�rka nie jest u�ywana */
	hash_table[idx] = malloc(data_size);
	if(NULL!=hash_table[idx])
		memset(hash_table[idx], 0, data_size);
	return hash_table[idx];
}

/* ------------------------------------------------------------------
   Usuni�cie klucza

   Funkcja usuwa klucz o podanej warto�ci i dane z nim skojarzone.
   Zwraca 1 gdy odnaleziono podany klucz i usuni�cie powiod�o si�, lub 0 w
   przeciwnym wypadku.
*/
int htbl_remove_key(const char *key)
{
	DWORD idx = htbl_calc_hash(key);
	if(hash_table[idx]==NULL)
	{
		/* nie odnaleziono klucza */
		printf("\nKlucz do usuni�cia nie istnieje.\n");
		return 0;
	};
	/* odnaleziono, usu� skojarzone dane i ustaw kom�rk� jako nie u�ywan� */
	htbl_delete_item_callback(hash_table[idx], idx);
	return 1;
}

/* ------------------------------------------------------------------
   Odnalezienie danych wg klucza

   Funkcja odszukuje dane skojarzone z podanym kluczem, korzystaj�c
   z tablicy hash.
   Zwraca wska�nik do danych, lub NULL gdy klucza nie odnaleziono.
*/
const void * htbl_find_key(const char *key)
{
	DWORD idx = htbl_calc_hash(key);
	if(hash_table[idx]==NULL)
		/* nie odnaleziono klucza */
		return NULL;
	return hash_table[idx];
}

/* ------------------------------------------------------------------
   Iteracja po wszystkich zaj�tych elementach tablicy hash

   Funkcja przegl�da tablic� hash wyszukuj�c elementy zaj�te. Dla ka�dego z
   nich wo�ana jest funkcja user_func, kt�rej parametrem jest wska�nik do
   danych skojarzonych z kluczem i warto�� hash.

   Funkcja ta jest u�ywana do �atwego przegl�dania tablicy.
*/
void htbl_for_each(HASHTBL_CALLBACK_FUNC user_func)
{
   DWORD i;
   for(i=0; i<HASH_TABLE_SIZE; i++)
      if(hash_table[i]!=NULL)
         user_func(hash_table[i], i);
}
