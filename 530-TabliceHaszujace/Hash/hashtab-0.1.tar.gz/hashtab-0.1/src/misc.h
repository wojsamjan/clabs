/***************************************************************************

   Deklaracje, typy i funkcje pomocnicze

***************************************************************************/   

#ifndef __misc_h
#define __misc_h

#define		DWORD	unsigned long

#ifndef stricmp
#define stricmp strcmp
#endif

/* zako�czenie programu z podaniem komunikatu o b��dzie */
void err_terminate(const char *msg);


#endif
