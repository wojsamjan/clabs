/***************************************************************************

  G��wny punkt wej�cia aplikacji

***************************************************************************/

#include <string.h>
#include <stdio.h>
#include "misc.h"
#include "command.h"
#include "hashtbl.h"

#define CMD_BUF   128

int main(int argc, char* argv[])
{
   char *arg, *cmd;
   char buf[CMD_BUF];

   htbl_initialize();

   do
   {
      printf("\n> ");
      fgets(buf, CMD_BUF-1, stdin);
    //^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
      cmd = strtok(buf, " \n\r");
      arg = strtok(NULL, "\r\n");
      cmnd_recognize_and_execute(cmd, arg);
   }
   while(stricmp(cmd, "exit"));

   htbl_finalize();
      
   return 0;
}

 