/*************************************************************************

  struktura danych u�ywana w bazie i funkcje operuj�ce na strukturze
  danych

*************************************************************************/

#ifndef __DATA_H
#define __DATA_H

#define	DT_KEY_SIZE		6				/* max. d�ugo�� klucza */
#define DT_AUTHOR_SIZE	24				/* max. d�ugo�� nazwiska autora */
#define DT_TITLE_SIZE	24				/* max. d�ugo�� tytu�u */

typedef struct tBOOK
{
	char key[DT_KEY_SIZE+1];				/* klucz */
	char author[DT_AUTHOR_SIZE+1];		/* autor */
	char title[DT_TITLE_SIZE+1];			/* tytu� */
	int	 year_of_issue;					/* rok wydania */
} BOOK;

void data_print(BOOK *data);
void data_print_table_header(void);
void data_print_table_separator(void);
void data_delimited_to_data(BOOK *data, char *delimited);

#endif
