/***************************************************************************

  Operacje plikowe - zapis i odczyt bazy danych z pliku
  implementacja

****************************************************************************/

#include <stdio.h>
#include <string.h>
#include "fileio.h"
#include "hashtbl.h"
#include "misc.h"
#include "data.h"

FILE *fStream;

/* Funkcja wykorzystywana przez funkcj� iteracyjn� do zapisu rekordu danych */
void file_write_element_callback(void *item, DWORD hash_value)
{
	fwrite(item, sizeof(BOOK), 1, fStream);
}

/* ----------------------------------------------------------------------
   Zapis bazy danych do pliku.

   Dokonuje zapisu danych korzystaj�c z tablicy hash i funkcji iteracyjnej.
   Zapisywane s� tylko dane. Tablica hash nie jest zapisywana, gdy� mo�e by�
   w prosty spos�b odbudowana podczas otwierania pliku.
*/
int file_write_data(char *fname)
{
	if(NULL==(fStream=fopen(fname, "wb")))
	{
		printf("\nNie mo�na otworzy� do zapisu pliku o podanej nazwie.\n");
		return 0;
	};

	/* zapisz wszystkie dane */
	htbl_for_each(file_write_element_callback);
	fclose(fStream);
	return 1;
}

/* ----------------------------------------------------------------------
   Odczyt bazy danych z pliku do pami�ci

   Dane odczytane z pliku s� umieszczane w pami�ci. Jednocze�nie odbudowywana
   jest tablica hash.
*/
int file_read_data(const char *fname)
{
	BOOK buf, *bPtr;

	if(NULL==(fStream=fopen(fname, "rb")))
	{
		printf("\nNie mo�na otworzy� do odczytu pliku o podanej nazwie.\n");
		return 0;
	};
	while(1)
	{
		/* odczytaj element z pliku */
		if(1!=fread(&buf, sizeof(BOOK), 1, fStream))
         break;

		/* dodaj do hash table */
		if(NULL!=(bPtr=(BOOK *)htbl_insert_key(buf.key, sizeof(BOOK))))
			memcpy(bPtr, &buf, sizeof(BOOK));
	}
	fclose(fStream);
	return 1;
}

